# %%
# `__future__` import required to use bar operators for optional type annotations
from __future__ import annotations  # Allows more recent type hints features
from pathlib import Path
from typing import TYPE_CHECKING, Literal

import numpy as np
from numpy.linalg import solve
import scipy as sp

from Pynite.Node3D import Node3D
from Pynite.Material import Material
from Pynite.Section import Section, SteelSection
from Pynite.PhysMember import PhysMember
from Pynite.Spring3D import Spring3D
from Pynite.Quad3D import Quad3D
from Pynite.Plate3D import Plate3D
from Pynite.LoadCombo import LoadCombo
from Pynite.Mesh import Mesh, RectangleMesh, AnnulusMesh, FrustrumMesh, CylinderMesh
from Pynite.ShearWall import ShearWall
from Pynite.MatFoundation import MatFoundation
from Pynite import Analysis

if TYPE_CHECKING:
    from typing import Dict, List
    from numpy import float64
    from numpy.typing import NDArray


# %%
class FEModel3D():
    """A 3D finite element model object. This object has methods and dictionaries to create, store,
       and retrieve results from a finite element model.
    """

    def __init__(self) -> None:
        """Creates a new 3D finite element model.
        """

        # Initialize the model's various dictionaries. The dictionaries will be prepopulated with
        # the data types they store, and then those types will be removed. This will give us the
        # ability to get type-based hints when using the dictionaries.

        self.nodes: Dict[str, Node3D] = {}             # A dictionary of the model's nodes
        self.materials: Dict[str, Material] = {}       # A dictionary of the model's materials
        self.sections: Dict[str, Section] = {}         # A dictonary of the model's cross-sections
        self.springs: Dict[str, Spring3D] = {}         # A dictionary of the model's springs
        self.members: Dict[str, PhysMember] = {}       # A dictionary of the model's physical members
        self.quads: Dict[str, Quad3D] = {}             # A dictionary of the model's quadiralterals
        self.plates: Dict[str, Plate3D] = {}           # A dictionary of the model's rectangular plates
        self.meshes: Dict[str, Mesh] = {}              # A dictionary of the model's meshes
        self.shear_walls: Dict[str, ShearWall] = {}    # A dictionary of the model's shear walls
        self.mats: Dict[str, MatFoundation] = {}       # A dictionary of the model's mat foundations
        self.load_combos: Dict[str, LoadCombo] = {}    # A dictionary of the model's load combinations
        self._D: Dict[str, NDArray[float64]] = {}      # A dictionary of the model's nodal displacements by load combination
        self._pushover_traces: Dict[str, Dict[str, List]] = {}

        self.solution: str | None = None  # Indicates the solution type for the latest run of the model

    def __repr__(self) -> str:
        return f"FEModel3D(solution={self.solution!r})"

    # Decorator marks this helper as not needing class/instance state.
    @staticmethod
    # Define helper that flattens node DOFs into a single index vector.
    def _build_dof_vector(*nodes: Node3D) -> NDArray[np.int64]:
        """Returns the flattened list of global DOF indices for the supplied nodes.

        Example for a 2-node member:

            [i_node*6 + (0..5), j_node*6 + (0..5)] -> 12 indices total.

        Once this vector is created we can operate on entire element sub-matrices via
        numpy broadcasting, instead of repeating the ``node.ID*6 + local_dof`` math in
        Python loops.
        """

        # Preallocate the DOF array (nodes * 6 DOFs each) as 64-bit ints.
        dofs = np.empty(len(nodes)*6, dtype=np.int64)

        # Build a template 0..5 array to shift per node.
        local = np.arange(6, dtype=np.int64)

        # Iterate through each supplied node with its ordinal index.
        for i, node in enumerate(nodes):

            # Compute the slice start for this node's 6 DOFs.
            start = i*6

            # Fill the slice with the node's base DOF plus the 0..5 offsets.
            dofs[start:start+6] = node.ID*6 + local
            
        # Hand back the populated DOF vector for downstream use.
        return dofs

    # Decorator again indicates no self access is needed for sparse conversion helper.
    @staticmethod
    # Define helper that converts a dense element block into coo-format row/col/data arrays.
    def _append_sparse_block(dofs: NDArray[np.int64], block: np.ndarray,
                              row_parts: list[np.ndarray], col_parts: list[np.ndarray],
                              data_parts: list[np.ndarray]) -> None:
        """Converts an element sub-matrix into row/col/data arrays for COO assembly.

        Compared to the former nested loops, this function handles the conversion in
        three numpy statements:
        1. ``rows = repeat(dofs, size)``
        2. ``cols = tile(dofs, size)``
        3. ``data = block.reshape(-1)``

        Optional zero filtering keeps the sparse storage compact.
        """

        # Ensure we are working with a float ndarray copy of the element block.
        block = np.asarray(block, dtype=float)

        # Cache the number of DOFs so we know how many row/column pairs we need; the sparse
        # COO builder needs every (row, col) pair formed by combining each DOF with
        # every other DOF because each element term contributes to one of those pairs.
        size = dofs.size

        # Flatten the element block into a 1-D vector matching the row/column pairing order so
        # ``flat[k]`` lines up with the kth (row, col) pair produced by the repeat/tile step;
        # this guarantees each coefficient from the local matrix lands on the
        # matching global DOF pair when we append into COO format.
        flat = block.reshape(-1)

        # Skip work entirely if this block contains only zeros; many elements (like nodal mass
        # shells) hand back zero-filled matrices, and filtering them here avoids appending
        # useless entries into the sparse accumulator.
        nonzero_mask = flat != 0.0

        # Return immediately when there is nothing to contribute to the sparse matrix.
        if not np.any(nonzero_mask):
            return

        # Build the repeated row indices for the full set of row/column combinations; repeating
        # each DOF ``size`` times yields the row portion of every (row, col) pair needed for COO insertion.
        rows = np.repeat(dofs, size)
        
        # Build the tiled column indices for that same set of combinations; tiling the DOF vector
        # produces the matching column portion for those same (row, col) pairs.
        cols = np.tile(dofs, size)

        # Append the nonzero row vector to the running parts list.
        row_parts.append(rows[nonzero_mask])

        # Append the nonzero column vector to the running parts list.
        col_parts.append(cols[nonzero_mask])
        
        # Append the nonzero data values to the running parts list.
        data_parts.append(flat[nonzero_mask])

    # Decorator marks this helper as purely functional for dense updates.
    @staticmethod
    # Define helper that adds an element block to the dense global matrix via vectorized indices.
    def _add_dense_block(global_matrix: np.ndarray, dofs: NDArray[np.int64], block: np.ndarray) -> None:
        """Adds an element block to the dense global matrix using vectorized indexing.

        ``np.ix_(dofs, dofs)`` builds every row/column combination of those DOFs, letting the
        12x12 or 24x24 block be summed in a single vectorized add.
        """

        # Convert the block to a float ndarray so dtype math aligns with the global matrix.
        block = np.asarray(block, dtype=float)

        # Use numpy advanced indexing to add the entire block in one statement.
        global_matrix[np.ix_(dofs, dofs)] += block

    @property
    def load_cases(self) -> List[str]:
        """Returns a list of all the load cases in the model (in alphabetical order).
        """

        # Create an empty list of load cases
        cases: List[str] = []

        # Step through each node
        for node in self.nodes.values():
            # Step through each nodal load
            for load in node.NodeLoads:
                # Get the load case for each nodal laod
                cases.append(load[2])

        # Step through each member
        for member in self.members.values():
            # Step through each member point load
            for load in member.PtLoads:
                # Get the load case for each member point load
                cases.append(load[3])
            # Step through each member distributed load
            for load in member.DistLoads:
                # Get the load case for each member distributed load
                cases.append(load[5])

        # Step through each plate/quad
        for plate in list(self.plates.values()) + list(self.quads.values()):
            # Step through each surface load
            for load in plate.pressures:
                # Get the load case for each plate/quad pressure
                cases.append(load[1])

        # Step through each shear wall helper
        for shear_wall in self.shear_walls.values():
            # Step through each shear wall shear load
            for load in shear_wall._shears:
                # Get the load case for each shear wall shear
                cases.append(load[2])

            # Step through each shear wall axial load
            for load in shear_wall._axials:
                # Get the load case for each shear wall axial
                cases.append(load[2])

        # Step through each mat foundation helper
        for mat in self.mats.values():
            # Step through each mat point load
            for load in mat.pt_loads:
                # Get the load case for each mat point load
                cases.append(load[3])

        # Remove duplicates and return the list (sorted ascending)
        return sorted(list(dict.fromkeys(cases)))

    def add_node(self, name: str, X: float, Y: float, Z: float) -> str:
        """Adds a new node to the model.

        :param name: A unique user-defined name for the node. If set to None or "" a name will be
                     automatically assigned.
        :type name: str
        :param X: The node's global X-coordinate.
        :type X: float
        :param Y: The node's global Y-coordinate.
        :type Y: float
        :param Z: The node's global Z-coordinate.
        :type Z: float
        :raises NameError: Occurs when the specified name already exists in the model.
        :return: The name of the node added to the model.
        :rtype: str
        """

        # Name the node or check it doesn't already exist
        if name:
            if name in self.nodes:
                raise NameError(f"Node name '{name}' already exists")
        else:
            # As a guess, start with the length of the dictionary
            name = "N" + str(len(self.nodes))
            count = 1
            while name in self.nodes:
                name = "N" + str(len(self.nodes) + count)
                count += 1

        # Create a new node
        new_node = Node3D(self, name, X, Y, Z)

        # Add the new node to the model
        self.nodes[name] = new_node

        # Flag the model as unsolved
        self.solution = None

        # Return the node name
        return name

    def add_material(self, name: str, E: float, G: float, nu: float, rho: float, fy: float | None = None) -> str:
        """Adds a new material to the model.

        :param name: A unique user-defined name for the material.
        :type name: str
        :param E: The modulus of elasticity of the material.
        :type E: float
        :param G: The shear modulus of elasticity of the material.
        :type G: float
        :param nu: Poisson's ratio of the material.
        :type nu: float
        :param rho: The density of the material
        :type rho: float
        :return: The name of the material added to the model.
        :rtype: str
        :raises NameError: Occurs when the specified name already exists in the model.
        """

        # Name the material or check it doesn't already exist
        if name:
            if name in self.materials:
                raise NameError(f"Material name '{name}' already exists")
        else:
            # As a guess, start with the length of the dictionary
            name = "M" + str(len(self.materials))
            count = 1
            while name in self.materials:
                name = "M" + str(len(self.materials) + count)
                count += 1

        # Create a new material
        new_material = Material(self, name, E, G, nu, rho, fy)

        # Add the new material to the model
        self.materials[name] = new_material

        # Flag the model as unsolved
        self.solution = None

        # Return the materal name
        return name

    def add_section(self, name: str, A: float, Iy: float, Iz: float, J: float) -> str:
        """Adds a cross-section to the model.

        :param name: A unique name for the cross-section.
        :type name: str
        :param A: Cross-sectional area of the section
        :type A: float
        :param Iy: The second moment of area the section about the Y (minor) axis
        :type Iy: float
        :param Iz: The second moment of area the section about the Z (major) axis
        :type Iz: float
        :param J: The torsion constant of the section
        :type J: float
        """

        # Name the section or check it doesn't already exist
        if name:
            if name in self.sections:
                raise NameError(f"Section name '{name}' already exists")
        else:
            # As a guess, start with the length of the dictionary
            name = "SC" + str(len(self.sections))
            count = 1
            while name in self.sections:
                name = "SC" + str(len(self.sections) + count)
                count += 1

        # Add the new section to the model
        self.sections[name] = Section(self, name, A, Iy, Iz, J)

        # Return the section name
        return name

    def add_steel_section(self, name: str, A: float, Iy: float, Iz: float, J: float, Zy: float, Zz: float, material_name: str) -> str:
        """Adds a cross-section to the model.

        :param name: A unique name for the cross-section.
        :type name: str
        :param A: Cross-sectional area of the section
        :type A: float
        :param Iy: The second moment of area the section about the Y (minor) axis
        :type Iy: float
        :param Iz: The second moment of area the section about the Z (major) axis
        :type Iz: float
        :param J: The torsion constant of the section
        :type J: float
        :param Zy: The section modulus about the Y (minor) axis
        :type Zy: float
        :param Zz: The section modulus about the Z (major) axis
        :type Zz: float
        :param material_name: The name of the steel material
        :type material_name: str
        """

        # Name the section or check it doesn't already exist
        if name:
            if name in self.sections:
                raise NameError(f"Section name '{name}' already exists")
        else:
            # As a guess, start with the length of the dictionary
            name = "SC" + str(len(self.sections))
            count = 1
            while name in self.sections:
                name = "SC" + str(len(self.sections) + count)
                count += 1

        # Add the new section to the model
        self.sections[name] = SteelSection(self, name, A, Iy, Iz, J, Zy, Zz, material_name)

        # Return the section name
        return name

    def add_spring(self, name: str, i_node: str, j_node: str, ks: float, tension_only: bool = False, comp_only: bool = False) -> str:
        """Adds a new spring to the model.

        :param name: A unique user-defined name for the spring. If ``None`` or ``""``, a name will be
                      automatically assigned.
        :type name: str
        :param i_node: The name of the i-node (start node).
        :type i_node: str
        :param j_node: The name of the j-node (end node).
        :type j_node: str
        :param ks: The spring constant (force/displacement).
        :type ks: float
        :param tension_only: Indicates if the member is tension-only, defaults to False
        :type tension_only: bool, optional
        :param comp_only: Indicates if the member is compression-only, defaults to False
        :type comp_only: bool, optional
        :raises NameError: Occurs when the specified name already exists in the model.
        :return: The name of the spring that was added to the model.
        :rtype: str
        """

        # Name the spring or check it doesn't already exist
        if name:
            if name in self.springs:
                raise NameError(f"Spring name '{name}' already exists")
        else:
            # As a guess, start with the length of the dictionary
            name = "S" + str(len(self.springs))
            count = 1
            while name in self.springs:
                name = "S" + str(len(self.springs) + count)
                count += 1

        # Lookup node names and safely handle exceptions
        try:
            pn_nodes = [self.nodes[node_name] for node_name in (i_node, j_node)]
        except KeyError as e:
            raise NameError(f"Node '{e.args[0]}' does not exist in the model")

        # Create a new spring
        new_spring = Spring3D(name, pn_nodes[0], pn_nodes[1],
                              ks, self.load_combos, tension_only=tension_only,
                              comp_only=comp_only)

        # Add the new spring to the model
        self.springs[name] = new_spring

        # Flag the model as unsolved
        self.solution = None

        # Return the spring name
        return name

    def add_member(self, name: str, i_node: str, j_node: str, material_name: str, section_name: str, rotation: float = 0.0, tension_only: bool = False, comp_only: bool = False) -> str:
        """Adds a new physical member to the model.

        :param name: A unique user-defined name for the member. If ``None`` or ``""``, a name will be automatically assigned
        :type name: str
        :param i_node: The name of the i-node (start node).
        :type i_node: str
        :param j_node: The name of the j-node (end node).
        :type j_node: str
        :param material_name: The name of the material of the member.
        :type material_name: str
        :param section_name: The name of the cross section to use for section properties.
        :type section_name: str
        :param rotation: The angle of rotation (degrees) of the member cross-section about its longitudinal (local x) axis. Default is 0.
        :type rotation: float, optional
        :param tension_only: Indicates if the member is tension-only, defaults to False
        :type tension_only: bool, optional
        :param comp_only: Indicates if the member is compression-only, defaults to False
        :type comp_only: bool, optional
        :raises NameError: Occurs if the specified name already exists.
        :return: The name of the member added to the model.
        :rtype: str
        """

        # Name the member or check it doesn't already exist
        if name:
            if name in self.members:
                raise NameError(f"Member name '{name}' already exists")
        else:
            # As a guess, start with the length of the dictionary
            name = "M" + str(len(self.members))
            count = 1
            while name in self.members:
                name = "M" + str(len(self.members)+count)
                count += 1

        # Lookup node names and safely handle exceptions
        try:
            pn_nodes = [self.nodes[node_name] for node_name in (i_node, j_node)]
        except KeyError as e:
            raise NameError(f"Node '{e.args[0]}' does not exist in the model")

        # Create a new member
        new_member = PhysMember(self, name, pn_nodes[0], pn_nodes[1], material_name, section_name, rotation=rotation, tension_only=tension_only, comp_only=comp_only)

        # Add the new member to the model
        self.members[name] = new_member

        # Flag the model as unsolved
        self.solution = None

        # Return the member name
        return name

    def add_plate(self, name: str, i_node: str, j_node: str, m_node: str, n_node: str, t: float, material_name: str, kx_mod: float = 1.0, ky_mod: float = 1.0) -> str:
        """Adds a new rectangular plate to the model. The plate formulation for in-plane (membrane)
        stiffness is based on an isoparametric formulation. For bending, it is based on a 12-term
        polynomial formulation. This element must be rectangular, and must not be used where a
        thick plate formulation is needed. For a more versatile plate element that can handle
        distortion and thick plate conditions, consider using the `add_quad` method instead.

        :param name: A unique user-defined name for the plate. If None or "", a name will be
                     automatically assigned.
        :type name: str
        :param i_node: The name of the i-node.
        :type i_node: str
        :param j_node: The name of the j-node.
        :type j_node: str
        :param m_node: The name of the m-node.
        :type m_node: str
        :param n_node: The name of the n-node.
        :type n_node: str
        :param t: The thickness of the element.
        :type t: float
        :param material_name: The name of the material for the element.
        :type material_name: str
        :param kx_mod: Stiffness modification factor for in-plane stiffness in the element's local
                       x-direction, defaults to 1 (no modification).
        :type kx_mod: float, optional
        :param ky_mod: Stiffness modification factor for in-plane stiffness in the element's local
                       y-direction, defaults to 1 (no modification).
        :type ky_mod: float, optional
        :raises NameError: Occurs when the specified name already exists in the model.
        :return: The name of the element added to the model.
        :rtype: str
        """

        # Name the plate or check it doesn't already exist
        if name:
            if name in self.plates:
                raise NameError(f"Plate name '{name}' already exists")
        else:
            # As a guess, start with the length of the dictionary
            name = "P" + str(len(self.plates))
            count = 1
            while name in self.plates:
                name = "P" + str(len(self.plates)+count)
                count += 1

        # Lookup node names and safely handle exceptions
        try:
            pn_nodes = [self.nodes[node_name] for node_name in (i_node, j_node, m_node, n_node)]
        except KeyError as e:
            raise NameError(f"Node '{e.args[0]}' does not exist in the model")

        # Create a new plate
        new_plate = Plate3D(name, pn_nodes[0], pn_nodes[1], pn_nodes[2], pn_nodes[3],
                            t, material_name, self, kx_mod, ky_mod)

        # Add the new plate to the model
        self.plates[name] = new_plate

        # Flag the model as unsolved
        self.solution = None

        # Return the plate name
        return name

    def add_quad(self, name: str, i_node: str, j_node: str, m_node: str, n_node: str,
                 t: float, material_name: str, kx_mod: float = 1.0, ky_mod: float = 1.0) -> str:
        """Adds a new quadrilateral to the model. The quad formulation for in-plane (membrane)
        stiffness is based on an isoparametric formulation. For bending, it is based on an MITC4
        formulation. This element handles distortion relatively well, and is appropriate for thick
        and thin plates. One limitation with this element is that it does a poor job of reporting
        corner stresses. Corner forces, however are very accurate. Center stresses are very
        accurate as well. For cases where corner stress results are important, consider using the
        `add_plate` method instead.

        :param name: A unique user-defined name for the quadrilateral. If None or "", a name will
                     be automatically assigned.
        :type name: str
        :param i_node: The name of the i-node.
        :type i_node: str
        :param j_node: The name of the j-node.
        :type j_node: str
        :param m_node: The name of the m-node.
        :type m_node: str
        :param n_node: The name of the n-node.
        :type n_node: str
        :param t: The thickness of the element.
        :type t: float
        :param material_name: The name of the material for the element.
        :type material_name: str
        :param kx_mod: Stiffness modification factor for in-plane stiffness in the element's local
            x-direction, defaults to 1 (no modification).
        :type kx_mod: float, optional
        :param ky_mod: Stiffness modification factor for in-plane stiffness in the element's local
            y-direction, defaults to 1 (no modification).
        :type ky_mod: float, optional
        :raises NameError: Occurs when the specified name already exists in the model.
        :return: The name of the element added to the model.
        :rtype: str
        """

        # Name the quad or check it doesn't already exist
        if name:
            if name in self.quads:
                raise NameError(f"Quad name '{name}' already exists")
        else:
            # As a guess, start with the length of the dictionary
            name = "Q" + str(len(self.quads))
            count = 1
            while name in self.quads:
                name = "Q" + str(len(self.quads) + count)
                count += 1

        # Lookup node names and safely handle exceptions
        try:
            pn_nodes = [self.nodes[node_name] for node_name in (i_node, j_node, m_node, n_node)]
        except KeyError as e:
            raise NameError(f"Node '{e.args[0]}' does not exist in the model")

        # Create a new member
        new_quad = Quad3D(name, pn_nodes[0], pn_nodes[1], pn_nodes[2], pn_nodes[3],
                          t, material_name, self, kx_mod, ky_mod)

        # Add the new member to the model
        self.quads[name] = new_quad

        # Flag the model as unsolved
        self.solution = None

        # Return the quad name
        return name

    def add_rectangle_mesh(self, name: str, mesh_size: float, width: float, height: float, thickness: float, material_name: str, kx_mod: float = 1.0, ky_mod: float = 1.0, origin: list | tuple = (0, 0, 0), plane: str = 'XY', x_control: list | None = None, y_control: list | None = None, start_node: str | None = None, start_element: str | None = None, element_type: str = 'Quad') -> str:
        """Adds a rectangular mesh of elements to the model.

        :param name: A unique name for the mesh.
        :type name: str
        :param mesh_size: The desired mesh size.
        :type mesh_size: float
        :param width: The overall width of the rectangular mesh measured along its local x-axis.
        :type width: float
        :param height: The overall height of the rectangular mesh measured along its local y-axis.
        :type height: float
        :param thickness: The thickness of each element in the mesh.
        :type thickness: float
        :param material_name: The name of the material for elements in the mesh.
        :type material_name: str
        :param kx_mod: Stiffness modification factor for in-plane stiffness in the element's local x-direction. Defaults to 1.0 (no modification).
        :type kx_mod: float, optional
        :param ky_mod: Stiffness modification factor for in-plane stiffness in the element's local y-direction. Defaults to 1.0 (no modification).
        :type ky_mod: float, optional
        :param origin: The origin of the regtangular mesh's local coordinate system. Defaults to [0, 0, 0]
        :type origin: list, optional
        :param plane: The plane the mesh will be parallel to. Options are 'XY', 'YZ', and 'XZ'. Defaults to 'XY'.
        :type plane: str, optional
        :param x_control: A list of control points along the mesh's local x-axis to work into the mesh. Defaults to `None`.
        :type x_control: list, optional
        :param y_control: A list of control points along the mesh's local y-axis to work into the mesh. Defaults to None.
        :type y_control: list, optional
        :param start_node: The name of the first node in the mesh. If set to `None` the program will use the next available node name. Default is `None`.
        :type start_node: str, optional
        :param start_element: The name of the first element in the mesh. If set to `None` the program will use the next available element name. Default is `None`.
        :type start_element: str, optional
        :param element_type: They type of element to make the mesh out of. Either 'Quad' or 'Rect'. Defaults to 'Quad'.
        :type element_type: str, optional
        :raises NameError: Occurs when the specified name already exists in the model.
        :return: The name of the mesh added to the model.
        :rtype: str
        """

        # Check if a mesh name has been provided
        if name:
            # Check that the mesh name isn't already being used
            if name in self.meshes: raise NameError(f"Mesh name '{name}' already exists")
        # Rename the mesh if necessary
        else:
            name = self.unique_name(self.meshes, 'MSH')

        # Identify the starting node and element
        if start_node is None:
            start_node = self.unique_name(self.nodes, 'N')
        if element_type == 'Rect' and start_element is None:
            start_element = self.unique_name(self.plates, 'R')
        elif element_type == 'Quad' and start_element is None:
            start_element = self.unique_name(self.quads, 'Q')

        # Create the mesh
        new_mesh = RectangleMesh(mesh_size, width, height, thickness, material_name, self, kx_mod,
                                 ky_mod, origin, plane, x_control, y_control, start_node,
                                 start_element, element_type=element_type)

        # Add the new mesh to the `Meshes` dictionary
        self.meshes[name] = new_mesh

        # Flag the model as unsolved
        self.solution = None

        # Return the mesh's name
        return name

    def add_annulus_mesh(self, name: str, mesh_size: float, outer_radius: float, inner_radius: float, thickness: float, material_name: str, kx_mod: float = 1.0, ky_mod: float = 1.0, origin: list | tuple = (0, 0, 0), axis: str = 'Y', start_node: str | None = None, start_element: str | None = None) -> str:
        """Adds a mesh of quadrilaterals forming an annulus (a donut).

        :param name: A unique name for the mesh.
        :type name: str
        :param mesh_size: The target mesh size.
        :type mesh_size: float
        :param outer_radius: The radius to the outside of the annulus.
        :type outer_radius: float
        :param inner_radius: The radius to the inside of the annulus.
        :type inner_radius: float
        :param thickness: Element thickness.
        :type thickness: float
        :param material_name: The name of the element material.
        :type material_name: str
        :param kx_mod: Stiffness modification factor for radial stiffness in the element's local
                       x-direction. Default is 1.0 (no modification).
        :type kx_mod: float, optional
        :param ky_mod: Stiffness modification factor for meridional stiffness in the element's
                       local y-direction. Default is 1.0 (no modification).
        :type ky_mod: float, optional
        :param origin: The origin of the mesh. The default is [0, 0, 0].
        :type origin: list, optional
        :param axis: The global axis about which the mesh will be generated. The default is 'Y'.
        :type axis: str, optional
        :param start_node: The name of the first node in the mesh. If set to `None` the program
                           will use the next available node name. Default is `None`.
        :type start_node: str, optional
        :param start_element: The name of the first element in the mesh. If set to `None` the
                              program will use the next available element name. Default is `None`.
        :type start_element: str, optional
        :raises NameError: Occurs if the specified name already exists in the model.
        :return: The name of the mesh added to the model.
        :rtype: str
        """

        # Check if a mesh name has been provided
        if name:
            # Check that the mesh name doesn't already exist
            if name in self.meshes: raise NameError(f"Mesh name '{name}' already exists")
        # Give the mesh a new name if necessary
        else:
            name = self.unique_name(self.meshes, 'MSH')

        # Identify the starting node and element
        if start_node is None:
            start_node = self.unique_name(self.nodes, 'N')
        if start_element is None:
            start_element = self.unique_name(self.quads, 'Q')

        # Create a new mesh
        new_mesh = AnnulusMesh(mesh_size, outer_radius, inner_radius, thickness, material_name, self,
                               kx_mod, ky_mod, origin, axis, start_node, start_element)

        # Add the new mesh to the `Meshes` dictionary
        self.meshes[name] = new_mesh

        # Flag the model as unsolved
        self.solution = None

        # Return the mesh's name
        return name

    def add_frustrum_mesh(self, name: str, mesh_size: float, large_radius: float, small_radius: float, height: float, thickness: float, material_name: str, kx_mod: float = 1.0, ky_mod: float = 1.0, origin: list | tuple = (0, 0, 0), axis: str = 'Y', start_node: str | None = None, start_element: str | None = None) -> str:
        """Adds a mesh of quadrilaterals forming a frustrum (a cone intersected by a horizontal plane).

        :param name: A unique name for the mesh.
        :type name: str
        :param mesh_size: The target mesh size
        :type mesh_size: float
        :param large_radius: The larger of the two end radii.
        :type large_radius: float
        :param small_radius: The smaller of the two end radii.
        :type small_radius: float
        :param height: The height of the frustrum.
        :type height: float
        :param thickness: The thickness of the elements.
        :type thickness: float
        :param material_name: The name of the element material.
        :type material_name: str
        :param kx_mod: Stiffness modification factor for radial stiffness in each element's local x-direction, defaults to 1 (no modification).
        :type kx_mod: float, optional
        :param ky_mod: Stiffness modification factor for meridional stiffness in each element's local y-direction, defaults to 1 (no modification).
        :type ky_mod: float, optional
        :param origin: The origin of the mesh, defaults to [0, 0, 0].
        :type origin: list, optional
        :param axis: The global axis about which the mesh will be generated, defaults to 'Y'.
        :type axis: str, optional
        :param start_node: The name of the first node in the mesh. If set to None the program will use the next available node name, defaults to None.
        :type start_node: str, optional
        :param start_element: The name of the first element in the mesh. If set to `None` the
                              program will use the next available element name, defaults to None
        :type start_element: str, optional
        :raises NameError: Occurs if the specified name already exists.
        :return: The name of the mesh added to the model.
        :rtype: str
        """

        # Check if a name has been provided
        if name:
            # Check that the mesh name doesn't already exist
            if name in self.meshes: raise NameError(f"Mesh name '{name}' already exists")
        # Give the mesh a new name if necessary
        else:
            name = self.unique_name(self.meshes, 'MSH')

        # Identify the starting node and element
        if start_node is None:
            start_node = self.unique_name(self.nodes, 'N')
        if start_element is None:
            start_element = self.unique_name(self.quads, 'Q')

        # Create a new mesh
        new_mesh = FrustrumMesh(mesh_size, large_radius, small_radius, height, thickness, material_name,
                                self, kx_mod, ky_mod, origin, axis, start_node, start_element)

        # Add the new mesh to the `Meshes` dictionary
        self.meshes[name] = new_mesh

        # Flag the model as unsolved
        self.solution = None

        # Return the mesh's name
        return name

    def add_cylinder_mesh(self, name:str, mesh_size:float, radius:float, height:float,
                          thickness:float, material_name:str, kx_mod:float = 1,
                          ky_mod:float = 1, origin:list | tuple = (0, 0, 0),
                          axis:str = 'Y', num_elements:int | None = None,
                          start_node: str | None = None, start_element:str | None = None,
                          element_type:str = 'Quad') -> str:
        """Adds a mesh of elements forming a cylinder.

        :param name: A unique name for the mesh.
        :type name: str
        :param mesh_size: The target mesh size.
        :type mesh_size: float
        :param radius: The radius of the cylinder.
        :type radius: float
        :param height: The height of the cylinder.
        :type height: float
        :param thickness: Element thickness.
        :type thickness: float
        :param material_name: The name of the element material.
        :type material_name: str
        :param kx_mod: Stiffness modification factor for hoop stiffness in each element's local
                       x-direction. Defaults to 1.0 (no modification).
        :type kx_mod: int, optional
        :param ky_mod: Stiffness modification factor for meridional stiffness in each element's
                       local y-direction. Defaults to 1.0 (no modification).
        :type ky_mod: int, optional
        :param origin: The origin [X, Y, Z] of the mesh. Defaults to [0, 0, 0].
        :type origin: list, optional
        :param axis: The global axis about which the mesh will be generated. Defaults to 'Y'.
        :type axis: str, optional
        :param num_elements: The number of elements to use to form each course of elements. This
                             is typically only used if you are trying to match the nodes to another
                             mesh's nodes. If set to `None` the program will automatically
                             calculate the number of elements to use based on the mesh size.
                             Defaults to None.
        :type num_elements: int, optional
        :param start_node: The name of the first node in the mesh. If set to `None` the program
                           will use the next available node name. Defaults to `None`.
        :type start_node: str, optional
        :param start_element: The name of the first element in the mesh. If set to `None` the
                              program will use the next available element name. Defaults to `None`.
        :type start_element: str, optional
        :param element_type: The type of element to make the mesh out of. Either 'Quad' or 'Rect'.
                             Defaults to 'Quad'.
        :type element_type: str, optional
        :raises NameError: Occurs when the specified mesh name is already being used in the model.
        :return: The name of the mesh added to the model
        :rtype: str
        """

        # Check if a name has been provided
        if name:
            # Check that the mesh name doesn't already exist
            if name in self.meshes: raise NameError(f"Mesh name '{name}' already exists")
        # Give the mesh a new name if necessary
        else:
            name = self.unique_name(self.meshes, 'MSH')

        # Identify the starting node and element
        if start_node is None:
            start_node = self.unique_name(self.nodes, 'N')
        if element_type == 'Rect' and start_element is None:
            start_element = self.unique_name(self.plates, 'R')
        elif element_type == 'Quad' and start_element is None:
            start_element = self.unique_name(self.quads, 'Q')

        # Create a new mesh
        new_mesh = CylinderMesh(mesh_size, radius, height, thickness, material_name, self,
                                kx_mod, ky_mod, origin, axis, start_node, start_element,
                                num_elements, element_type)

        # Add the new mesh to the `Meshes` dictionary
        self.meshes[name] = new_mesh

        # Flag the model as unsolved
        self.solution = None

        # Return the mesh's name
        return name

    def add_shear_wall(self, name: str, mesh_size: float, length: float, height: float, thickness: float, material_name: str, ky_mod: float = 0.35, plane: Literal['XY', 'YZ'] = 'XY', origin: List[float] = [0, 0, 0]):
        """Adds a meshed shear wall helper to the model.

        The shear wall utility generates a regular mesh for a rectangular wall panel and
        keeps references to the created nodes and elements for convenience.

        :param name: Unique name for the shear wall.
        :type name: str
        :param mesh_size: Target element size for the mesh generator.
        :type mesh_size: float
        :param length: Wall length along the local x-direction.
        :type length: float
        :param height: Wall height along the local y-direction.
        :type height: float
        :param thickness: Element thickness for the wall mesh.
        :type thickness: float
        :param material_name: Name of the material to assign to elements.
        :type material_name: str
        :param ky_mod: In-plane stiffness modifier in local y; default 0.35.
        :type ky_mod: float, optional
        :param plane: Global plane for the wall: ``'XY'`` or ``'YZ'``; default ``'XY'``.
        :type plane: Literal['XY','YZ'], optional
        :param origin: Global origin [X, Y, Z] of the wall; default ``[0,0,0]``.
        :type origin: list[float], optional
        :return: None
        :rtype: NoneType
        """

        # Check if a name has been provided
        if name:
            # Check that the shear wall name doesn't already exist
            if name in self.shear_walls: raise NameError(f"Shear wall name '{name}' already exists")
        # Give the shear wall a new name if necessary
        else:
            name = self.unique_name(self.shear_walls, 'SW')

        # Create a new shear wall
        new_shear_wall = ShearWall(self, name, mesh_size, length, height, thickness, material_name, ky_mod, origin, plane)

        # Add the wall to the model
        self.shear_walls[name] = new_shear_wall

        # Flag the model as unsolved
        self.solution = None

    def add_mat_foundation(self, name, mesh_size, length_X, length_Z, thickness, material_name, ks, origin=[0, 0, 0], x_control=[], y_control=[]):

        # Check if a name has been provided
        if name:
            # Check that the mat foundation name doesn't already exist
            if name in self.mats: raise NameError(f"Mat foundation name '{name}' already exists")
        # Give the mat a new name if necessary
        else:
            name = self.unique_name(self.mats, 'MAT')

        new_mat = MatFoundation(name, mesh_size, length_X, length_Z, thickness, material_name, self, ks, origin, x_control, y_control)

        # Add the mat foundation to the model
        self.mats[name] = new_mat

        # Flag the model as unsolved
        self.solution = None

    def merge_duplicate_nodes(self, tolerance: float = 0.001) -> list:
        """Removes duplicate nodes from the model and returns a list of the removed node names.

        :param tolerance: The maximum distance between two nodes in order to consider them duplicates. Defaults to 0.001.
        :type tolerance: float, optional
        :return: A list of the names of the nodes that were removed from the model.
        """

        # Initialize a dictionary marking where each node is used
        node_lookup = {node_name: [] for node_name in self.nodes.keys()}
        element_dicts = ('springs', 'members', 'plates', 'quads')
        node_types = ('i_node', 'j_node', 'm_node', 'n_node')

        # Step through each dictionary of elements in the model (springs, members, plates, quads)
        for element_dict in element_dicts:

            # Step through each element in the dictionary
            for element in getattr(self, element_dict).values():

                # Step through each possible node type in the element (i-node, j-node, m-node, n-node)
                for node_type in node_types:

                    # Get the current element's node having the current type
                    # Return `None` if the element doesn't have this node type
                    node = getattr(element, node_type, None)

                    # Determine if the node exists on the element
                    if node is not None:
                        # Add the element to the list of elements attached to the node
                        node_lookup[node.name].append((element, node_type))

        # Make a list of the names of each node in the model
        node_names = list(self.nodes.keys())

        # Make a list of nodes to be removed from the model
        remove_list = []

        # Step through each node in the copy of the `Nodes` dictionary
        for i, node_1_name in enumerate(node_names):

            # Skip iteration if `node_1` has already been removed
            if node_lookup[node_1_name] is None:
                continue

            # There is no need to check `node_1` against itself
            for node_2_name in node_names[i + 1:]:

                # Skip iteration if node_2 has already been removed
                if node_lookup[node_2_name] is None:
                    continue

                # Calculate the distance between nodes
                if self.nodes[node_1_name].distance(self.nodes[node_2_name]) > tolerance:
                    continue

                # Replace references to `node_2` in each element with references to `node_1`
                for element, node_type in node_lookup[node_2_name]:
                    setattr(element, node_type, self.nodes[node_1_name])

                # Flag `node_2` as no longer used
                node_lookup[node_2_name] = None

                # Merge any boundary conditions
                support_cond = ('support_DX', 'support_DY', 'support_DZ', 'support_RX', 'support_RY', 'support_RZ')
                for dof in support_cond:
                    if getattr(self.nodes[node_2_name], dof) == True:
                        setattr(self.nodes[node_1_name], dof, True)

                # Merge any spring supports
                spring_cond = ('spring_DX', 'spring_DY', 'spring_DZ', 'spring_RX', 'spring_RY', 'spring_RZ')
                for dof in spring_cond:
                    value = getattr(self.nodes[node_2_name], dof)
                    if value != [None, None, None]:
                        setattr(self.nodes[node_1_name], dof, value)

                # Fix the mesh labels
                for mesh in self.meshes.values():

                    # Fix the nodes in the mesh
                    if node_2_name in mesh.nodes.keys():

                        # Attach the correct node to the mesh
                        mesh.nodes[node_2_name] = self.nodes[node_1_name]

                        # Fix the dictionary key
                        mesh.nodes[node_1_name] = mesh.nodes.pop(node_2_name)

                    # Fix the elements in the mesh
                    for element in mesh.elements.values():
                        if node_2_name == element.i_node.name: element.i_node = self.nodes[node_1_name]
                        if node_2_name == element.j_node.name: element.j_node = self.nodes[node_1_name]
                        if node_2_name == element.m_node.name: element.m_node = self.nodes[node_1_name]
                        if node_2_name == element.n_node.name: element.n_node = self.nodes[node_1_name]

                # Add the node to the `remove` list
                remove_list.append(node_2_name)

        # Remove `node_2` from the model's `Nodes` dictionary
        for node_name in remove_list:
            self.nodes.pop(node_name)

        # Flag the model as unsolved
        self.solution = None

        # Return the list of removed nodes
        return remove_list

    def delete_node(self, node_name: str):
        """Removes a node from the model. All nodal loads associated with the node and elements attached to the node will also be removed.

        :param node_name: The name of the node to be removed.
        :type node_name: str
        """

        # Remove the node. Nodal loads are stored within the node, so they
        # will be deleted automatically when the node is deleted.
        self.nodes.pop(node_name)

        # Find any elements attached to the node and remove them
        self.members = {name: member for name, member in self.members.items() if member.i_node.name != node_name and member.j_node.name != node_name}
        self.plates = {name: plate for name, plate in self.plates.items() if plate.i_node.name != node_name and plate.j_node.name != node_name and plate.m_node.name != node_name and plate.n_node.name != node_name}
        self.quads = {name: quad for name, quad in self.quads.items() if quad.i_node.name != node_name and quad.j_node.name != node_name and quad.m_node.name != node_name and quad.n_node.name != node_name}

        # Flag the model as unsolved
        self.solution = None

    def delete_spring(self, spring_name: str):
        """Removes a spring from the model.

        :param spring_name: The name of the spring to be removed.
        :type spring_name: str
        """

        # Remove the spring
        self.springs.pop(spring_name)

        # Flag the model as unsolved
        self.solution = None

    def delete_member(self, member_name:str):
        """Removes a member from the model. All member loads associated with the member will also
           be removed.

        :param member_name: The name of the member to be removed.
        :type member_name: str
        """

        # Remove the member. Member loads are stored within the member, so they
        # will be deleted automatically when the member is deleted.
        self.members.pop(member_name)

        # Flag the model as unsolved
        self.solution = None

    def delete_mesh(self, mesh_name: str) -> None:
        """Removes a mesh from the model. The mesh's elements are removed, but nodes that are
        shared with elements outside the mesh are preserved.

        :param mesh_name: The name of the mesh to be removed.
        :type mesh_name: str
        :raises KeyError: Occurs when the specified mesh does not exist in the model.
        """

        # Check if the mesh exists
        if mesh_name not in self.meshes:
            raise KeyError(f"Mesh '{mesh_name}' does not exist in the model.")

        # Get the mesh
        mesh = self.meshes[mesh_name]

        # Remove the mesh's nodes and elements from the model (preserving shared nodes)
        mesh._remove_from_model()

        # Remove the mesh from the model's mesh dictionary
        self.meshes.pop(mesh_name)

        # Flag the model as unsolved
        self.solution = None

    def def_support(self, node_name: str, support_DX: bool = False, support_DY: bool = False,
                    support_DZ: bool = False, support_RX: bool = False, support_RY: bool = False,
                    support_RZ: bool = False):
        """Defines the support conditions at a node. Nodes will default to fully unsupported
           unless specified otherwise.

        :param node_name: The name of the node where the support is being defined.
        :type node_name: str
        :param support_DX: Indicates whether the node is supported against translation in the
                           global X-direction. Defaults to False.
        :type support_DX: bool, optional
        :param support_DY: Indicates whether the node is supported against translation in the
                           global Y-direction. Defaults to False.
        :type support_DY: bool, optional
        :param support_DZ: Indicates whether the node is supported against translation in the
                           global Z-direction. Defaults to False.
        :type support_DZ: bool, optional
        :param support_RX: Indicates whether the node is supported against rotation about the
                           global X-axis. Defaults to False.
        :type support_RX: bool, optional
        :param support_RY: Indicates whether the node is supported against rotation about the
                           global Y-axis. Defaults to False.
        :type support_RY: bool, optional
        :param support_RZ: Indicates whether the node is supported against rotation about the
                           global Z-axis. Defaults to False.
        :type support_RZ: bool, optional
        """

        # Get the node to be supported
        try:
            node = self.nodes[node_name]
        except KeyError:
            raise NameError(f"Node '{node_name}' does not exist in the model")

        # Set the node's support conditions
        node.support_DX = support_DX
        node.support_DY = support_DY
        node.support_DZ = support_DZ
        node.support_RX = support_RX
        node.support_RY = support_RY
        node.support_RZ = support_RZ

        # Flag the model as unsolved
        self.solution = None

    def def_support_spring(self, node_name: str, dof: str, stiffness: float, direction: str | None = None):
        """Defines a spring support at a node.

        :param node_name: The name of the node to apply the spring support to.
        :type node_name: str
        :param dof: The degree of freedom to apply the spring support to.
        :type dof: str ('DX', 'DY', 'DZ', 'RX', 'RY', or 'RZ')
        :param stiffness: The translational or rotational stiffness of the spring support.
        :type stiffness: float
        :param direction: The direction in which the spring can act. '+' allows the spring to resist positive displacements. '-' allows the spring to resist negative displacements. None allows the spring to act in both directions. Default is None.
        :type direction: str or None ('+', '-', None), optional
        :raises ValueError: Occurs when an invalid support spring direction has been specified.
        :raises ValueError: Occurs when an invalid support spring degree of freedom has been specified.
        """

        if dof in ('DX', 'DY', 'DZ', 'RX', 'RY', 'RZ'):
            if direction in ('+', '-', None):
                try:
                    if dof == 'DX':
                        self.nodes[node_name].spring_DX = [stiffness, direction, True]
                    elif dof == 'DY':
                        self.nodes[node_name].spring_DY = [stiffness, direction, True]
                    elif dof == 'DZ':
                        self.nodes[node_name].spring_DZ = [stiffness, direction, True]
                    elif dof == 'RX':
                        self.nodes[node_name].spring_RX = [stiffness, direction, True]
                    elif dof == 'RY':
                        self.nodes[node_name].spring_RY = [stiffness, direction, True]
                    elif dof == 'RZ':
                        self.nodes[node_name].spring_RZ = [stiffness, direction, True]
                except KeyError:
                    raise NameError(f"Node '{node_name}' does not exist in the model")
            else:
                raise ValueError('Invalid support spring direction. Specify \'+\', \'-\', or None.')
        else:
            raise ValueError('Invalid support spring degree of freedom. Specify \'DX\', \'DY\', \'DZ\', \'RX\', \'RY\', or \'RZ\'')

        # Flag the model as unsolved
        self.solution = None

    def def_node_disp(self, node_name:str, direction:str, magnitude:float):
        """Defines a nodal displacement at a node.

        :param node_name: The name of the node where the nodal displacement is being applied.
        :type node_name: str
        :param direction: The global direction the nodal displacement is being applied in. Displacements are 'DX', 'DY', and 'DZ'. Rotations are 'RX', 'RY', and 'RZ'.
        :type direction: str
        :param magnitude: The magnitude of the displacement.
        :type magnitude: float
        :raises ValueError: If an invalid displacement/rotation direction is provided.
        :raises NameError: If the specified node does not exist in the model.
        """

        # Validate the value of direction
        if direction not in ('DX', 'DY', 'DZ', 'RX', 'RY', 'RZ'):
            raise ValueError(f"direction must be 'DX', 'DY', 'DZ', 'RX', 'RY', or 'RZ'. {direction} was given.")

        # Get the node
        try:
            node = self.nodes[node_name]
        except KeyError:
            raise NameError(f"Node '{node_name}' does not exist in the model")

        if direction == 'DX':
            node.EnforcedDX = magnitude
        if direction == 'DY':
            node.EnforcedDY = magnitude
        if direction == 'DZ':
            node.EnforcedDZ = magnitude
        if direction == 'RX':
            node.EnforcedRX = magnitude
        if direction == 'RY':
            node.EnforcedRY = magnitude
        if direction == 'RZ':
            node.EnforcedRZ = magnitude

        # Flag the model as unsolved
        self.solution = None

    def def_releases(self, member_name:str, Dxi:bool=False, Dyi:bool=False, Dzi:bool=False,
                     Rxi:bool=False, Ryi:bool=False, Rzi:bool=False,
                     Dxj:bool=False, Dyj:bool=False, Dzj:bool=False,
                     Rxj:bool=False, Ryj:bool=False, Rzj:bool=False):
        """Defines member end releases for a member. All member end releases will default to unreleased unless specified otherwise.

        :param member_name: The name of the member to have its releases modified.
        :type member_name: str
        :param Dxi: Indicates whether the member is released axially at its start. Defaults to False.
        :type Dxi: bool, optional
        :param Dyi: Indicates whether the member is released for shear in the local y-axis at its start. Defaults to False.
        :type Dyi: bool, optional
        :param Dzi: Indicates whether the member is released for shear in the local z-axis at its start. Defaults to False.
        :type Dzi: bool, optional
        :param Rxi: Indicates whether the member is released for torsion at its start. Defaults to False.
        :type Rxi: bool, optional
        :param Ryi: Indicates whether the member is released for moment about the local y-axis at its start. Defaults to False.
        :type Ryi: bool, optional
        :param Rzi: Indicates whether the member is released for moment about the local z-axis at its start. Defaults to False.
        :type Rzi: bool, optional
        :param Dxj: Indicates whether the member is released axially at its end. Defaults to False.
        :type Dxj: bool, optional
        :param Dyj: Indicates whether the member is released for shear in the local y-axis at its end. Defaults to False.
        :type Dyj: bool, optional
        :param Dzj: Indicates whether the member is released for shear in the local z-axis. Defaults to False.
        :type Dzj: bool, optional
        :param Rxj: Indicates whether the member is released for torsion at its end. Defaults to False.
        :type Rxj: bool, optional
        :param Ryj: Indicates whether the member is released for moment about the local y-axis at its end. Defaults to False.
        :type Ryj: bool, optional
        :param Rzj: Indicates whether the member is released for moment about the local z-axis at its end. Defaults to False.
        :type Rzj: bool, optional
        """

        # Apply the end releases to the member
        try:
            self.members[member_name].Releases = [Dxi, Dyi, Dzi, Rxi, Ryi, Rzi, Dxj, Dyj, Dzj, Rxj, Ryj, Rzj]
        except KeyError:
            raise NameError(f"Member '{member_name}' does not exist in the model")

        # Flag the model as unsolved
        self.solution = None

    def add_load_combo(self, name:str, factors:dict, combo_tags:list | None = None):
        """Adds a load combination to the model.

        :param name: A unique name for the load combination (e.g. '1.2D+1.6L+0.5S' or 'Gravity Combo').
        :type name: str
        :param factors: A dictionary containing load cases and their corresponding factors (e.g. {'D':1.2, 'L':1.6, 'S':0.5}).
        :type factors: dict
        :param combo_tags: A list of tags used to categorize load combinations. Default is `None`. This can be useful for filtering results later on, or for limiting analysis to only those combinations with certain tags. This feature is provided for convenience. It is not necessary to use tags.
        :type combo_tags: list, optional
        """

        # Create a new load combination object
        new_combo = LoadCombo(name, combo_tags, factors)

        # Add the load combination to the dictionary of load combinations
        self.load_combos[name] = new_combo

        # Flag the model as solved
        self.solution = None

    def add_node_load(self, node_name:str, direction:str, P:float, case:str = 'Case 1'):
        """Adds a nodal load to the model.

        :param node_name: The name of the node where the load is being applied.
        :type node_name: str
        :param direction: The global direction the load is being applied in. Forces are `'FX'`, `'FY'`, and `'FZ'`. Moments are `'MX'`, `'MY'`, and `'MZ'`.
        :type direction: str
        :param P: The numeric value (magnitude) of the load.
        :type P: float
        :param case: The name of the load case the load belongs to. Defaults to 'Case 1'.
        :type case: str, optional
        :raises ValueError: Occurs when an invalid load direction was specified.
        """

        # Validate the value of direction
        if direction not in ('FX', 'FY', 'FZ', 'MX', 'MY', 'MZ'):
            raise ValueError(f"direction must be 'FX', 'FY', 'FZ', 'MX', 'MY', or 'MZ'. {direction} was given.")

        # Add the node load to the model
        try:
            self.nodes[node_name].NodeLoads.append((direction, P, case))
        except KeyError:
            raise NameError(f"Node '{node_name}' does not exist in the model")

        # Flag the model as unsolved
        self.solution = None

    def add_member_pt_load(self, member_name:str, direction:str, P:float, x:float, case:str = 'Case 1'):
        """Adds a member point load to the model.

        :param member_name: The name of the member the load is being applied to.
        :type member_name: str
        :param direction: The direction in which the load is to be applied. Valid values are `'Fx'`,
                          `'Fy'`, `'Fz'`, `'Mx'`, `'My'`, `'Mz'`, `'FX'`, `'FY'`, `'FZ'`, `'MX'`, `'MY'`, or `'MZ'`.
                          Note that lower-case notation indicates use of the beam's local
                          coordinate system, while upper-case indicates use of the model's global
                          coordinate system.
        :type direction: str
        :param P: The numeric value (magnitude) of the load.
        :type P: float
        :param x: The load's location along the member's local x-axis.
        :type x: float
        :param case: The load case to categorize the load under. Defaults to 'Case 1'.
        :type case: str, optional
        :raises ValueError: Occurs when an invalid load direction has been specified.
        """

        # Validate the value of direction
        if direction not in ('Fx', 'Fy', 'Fz', 'FX', 'FY', 'FZ', 'Mx', 'My', 'Mz', 'MX', 'MY', 'MZ'):
            raise ValueError(f"direction must be 'Fx', 'Fy', 'Fz', 'FX', 'FY', FZ', 'Mx', 'My', 'Mz', 'MX', 'MY', or 'MZ'. {direction} was given.")

        # Add the point load to the member
        try:
            self.members[member_name].PtLoads.append((direction, P, x, case))
        except KeyError:
            raise NameError(f"Member '{member_name}' does not exist in the model")

        # Flag the model as unsolved
        self.solution = None

    def add_member_dist_load(self, member_name: str, direction: str, w1: float, w2: float,
                             x1: float | None = None, x2: float | None = None,
                             case: str = 'Case 1', self_weight: bool = False):
        """Adds a member distributed load to the model.

        :param member_name: The name of the member the load is being appied to.
        :type member_name: str
        :param direction: The direction in which the load is to be applied. Valid values are `'Fx'`,
                          `'Fy'`, `'Fz'`, `'FX'`, `'FY'`, or `'FZ'`.
                          Note that lower-case notation indicates use of the beam's local
                          coordinate system, while upper-case indicates use of the model's global
                          coordinate system.
        :type direction: str
        :param w1: The starting value (magnitude) of the load.
        :type w1: float
        :param w2: The ending value (magnitude) of the load.
        :type w2: float
        :param x1: The load's start location along the member's local x-axis. If this argument is
                   not specified, the start of the member will be used. Defaults to `None`
        :type x1: float, optional
        :param x2: The load's end location along the member's local x-axis. If this argument is not
                   specified, the end of the member will be used. Defaults to `None`.
        :type x2: float, optional
        :param case: The load case to categorize the load under. Defaults to 'Case 1'.
        :type case: str, optional
        :param self_weight: Indicates whether this load is a self-weight load. Only set this to True if you are entering member self weight manually instead of using the `add_member_self_weight` method. This parameter is used by the modal analysis engine to determine whether to create a lumped mass for the load. Self-weight loads are already accounted for in modal analysis using a consistent mass matrix, so creating an additional lumped mass incorrect. Typically you will leave this value at the default value of `False`.
        :type self_weight: bool, optional
        :raises ValueError: Occurs when an invalid load direction has been specified.
        """

        # Validate the value of direction
        if direction not in ('Fx', 'Fy', 'Fz', 'FX', 'FY', 'FZ'):
            raise ValueError(f"direction must be 'Fx', 'Fy', 'Fz', 'FX', 'FY', or 'FZ'. {direction} was given.")
        # Determine if a starting and ending points for the load have been specified.
        # If not, use the member start and end as defaults
        if x1 == None:
            start = 0
        else:
            start = x1

        if x2 == None:
            end = self.members[member_name].L()
        else:
            end = x2

        # Add the distributed load to the member
        try:
            self.members[member_name].DistLoads.append((direction, w1, w2, start, end, case, self_weight))
        except KeyError:
            raise NameError(f"Member '{member_name}' does not exist in the model")

        # Flag the model as unsolved
        self.solution = None

    def add_member_self_weight(self, global_direction: str, factor: float, case: str = 'Case 1'):
        """Adds self weight to all members in the model. Note that this only works for members. Plate, quad, and spring elements will be ignored by this command.

        :param global_direction: The global direction to apply the member load in: 'FX', 'FY', or 'FZ'.
        :type global_direction: str
        :param factor: A factor to apply to the member self-weight. Can be used to account for items like connections, or to switch the direction of the self-weight load.
        :type factor: float
        :param case: The load case to apply the self-weight to. Defaults to 'Case 1'
        :type case: str, optional
        :raises ValueError: IF a local direction ('Fx', 'Fy', or 'Fz') is used instead of a global direction.
        """

        # Validate that a global direction was provided, not a local direction
        if global_direction in ('Fx', 'Fy', 'Fz'):
            raise ValueError(
                f"Local direction '{global_direction}' is not allowed for self-weight.  \
                    Use global directions 'FX', 'FY', or 'FZ' instead."
            )

        # Validate the value of direction
        if global_direction not in ('FX', 'FY', 'FZ'):
            raise ValueError(f"Direction must be 'FX', 'FY', or 'FZ'. {global_direction} was given.")

        # Step through each member in the model
        for member in self.members.values():

            # Calculate the self weight of the member
            self_weight = factor*member.material.rho*member.section.A

            # Add the self-weight load to the member
            self.add_member_dist_load(member.name, global_direction, self_weight, self_weight, case=case, self_weight=True)

        # No need to flag the model as unsolved. That has already been taken care of by our call to `add_member_dist_load`

    def add_plate_surface_pressure(self, plate_name: str, pressure: float, case: str = 'Case 1'):
        """Adds a surface pressure to the rectangular plate element.

        :param plate_name: The name for the rectangular plate to add the surface pressure to.
        :type plate_name: str
        :param pressure: The value (magnitude) for the surface pressure.
        :type pressure: float
        :param case: The load case to add the surface pressure to. Defaults to 'Case 1'.
        :type case: str, optional
        :raises Exception: Occurs when an invalid plate name has been specified.
        """

        # Add the surface pressure to the rectangle
        try:
            self.plates[plate_name].pressures.append([pressure, case])
        except KeyError:
            raise NameError(f"Plate '{plate_name}' does not exist in the model")

        # Flag the model as unsolved
        self.solution = None

    def add_quad_surface_pressure(self, quad_name: str, pressure: float, case: str = 'Case 1'):
        """Adds a surface pressure to the quadrilateral element.

        :param quad_name: The name for the quad to add the surface pressure to.
        :type quad_name: str
        :param pressure: The value (magnitude) for the surface pressure.
        :type pressure: float
        :param case: The load case to add the surface pressure to. Defaults to 'Case 1'.
        :type case: str, optional
        :raises Exception: Occurs when an invalid quad name has been specified.
        """

        # Add the surface pressure to the quadrilateral
        try:
            self.quads[quad_name].pressures.append([pressure, case])
        except KeyError:
            raise NameError(f"Quad '{quad_name}' does not exist in the model")

        # Flag the model as unsolved
        self.solution = None

    def delete_loads(self):
        """Deletes all loads from the model along with any results based on the loads.
        """

        # Delete the member loads and the calculated internal forces
        for member in self.members.values():
            member.DistLoads = []
            member.PtLoads = []
            member.SegmentsZ = []
            member.SegmentsY = []
            member.SegmentsX = []

        # Delete the plate loads
        for plate in self.plates.values():
            plate.pressures = []

        # Delete the quadrilateral loads
        for quad in self.quads.values():
            quad.pressures = []

        # Delete the nodal loads, calculated displacements, and calculated reactions
        for node in self.nodes.values():

            node.NodeLoads = []

            node.DX = {}
            node.DY = {}
            node.DZ = {}
            node.RX = {}
            node.RY = {}
            node.RZ = {}

            node.RxnFX = {}
            node.RxnFY = {}
            node.RxnFZ = {}
            node.RxnMX = {}
            node.RxnMY = {}
            node.RxnMZ = {}

        # Flag the model as unsolved
        self.solution = None

    def Ke(self, combo_name='Combo 1', log=False, check_stability=True, sparse=True):
        """Returns the model's global elastic stiffness matrix.

        The elastic stiffness matrix is returned in scipy's sparse COO format by default, which
        reduces memory usage and can be easily converted to other formats.

        :param combo_name: The load combination to get the elastic stiffness matrix for. Defaults to 'Combo 1'.
        :type combo_name: str, optional
        :param log: Prints updates to the console if set to True. Defaults to False.
        :type log: bool, optional
        :param check_stability: Causes Pynite to check for instabilities if set to True. Defaults
                                to True. Set to False if you want the model to run faster.
        :type check_stability: bool, optional
        :param sparse: Returns a sparse matrix if set to True, and a dense matrix otherwise.
                       Defaults to True.
        :type sparse: bool, optional
        :return: The global elastic stiffness matrix for the structure.
        :rtype: ndarray or coo_matrix
        """

        # Determine if a sparse matrix has been requested
        if sparse == True:
            # Instead of pushing one entry at a time, we keep batched row/col/data arrays
            # per element and concatenate once. This drastically cuts Python overhead.
            # Initialize the list of per-element row vectors for later concatenation.
            row_parts: list[np.ndarray] = []
            # Initialize the list of per-element column vectors for later concatenation.
            col_parts: list[np.ndarray] = []
            # Initialize the list of per-element data vectors for later concatenation.
            data_parts: list[np.ndarray] = []
        else:
            # Initialize a dense matrix of zeros
            Ke = np.zeros((len(self.nodes)*6, len(self.nodes)*6))

        # Add stiffness terms for each nodal spring in the model
        if log: print('- Adding nodal spring support stiffness terms to global stiffness matrix')
        for node in self.nodes.values():

            # Determine if the node has any spring supports
            if node.spring_DX[0] is not None:

                # Check for an active spring support
                if node.spring_DX[2] == True:
                    m, n = node.ID*6, node.ID*6
                    # Cache the spring stiffness value once for reuse below.
                    val = float(node.spring_DX[0])
                    if sparse == True:
                        # Record the row index associated with the restrained DOF.
                        row_parts.append(np.array([m], dtype=np.int64))
                        # Record the column index associated with the same DOF.
                        col_parts.append(np.array([n], dtype=np.int64))
                        # Record the spring stiffness contribution for this DOF.
                        data_parts.append(np.array([val], dtype=float))
                    else:
                        Ke[m, n] += val

            if node.spring_DY[0] is not None:

                # Check for an active spring support
                if node.spring_DY[2] == True:
                    m, n = node.ID*6 + 1, node.ID*6 + 1
                    # Capture the Y-direction spring stiffness once per DOF.
                    val = float(node.spring_DY[0])
                    if sparse == True:
                        # Store the row index for the Y spring term.
                        row_parts.append(np.array([m], dtype=np.int64))
                        # Store the column index for the Y spring term.
                        col_parts.append(np.array([n], dtype=np.int64))
                        # Store the spring stiffness coefficient for this DOF.
                        data_parts.append(np.array([val], dtype=float))
                    else:
                        Ke[m, n] += val

            if node.spring_DZ[0] is not None:

                # Check for an active spring support
                if node.spring_DZ[2] == True:
                    m, n = node.ID*6 + 2, node.ID*6 + 2
                    # Capture the Z-direction spring stiffness once per DOF.
                    val = float(node.spring_DZ[0])
                    if sparse == True:
                        # Store the row index for the Z spring contribution.
                        row_parts.append(np.array([m], dtype=np.int64))
                        # Store the column index for the Z spring contribution.
                        col_parts.append(np.array([n], dtype=np.int64))
                        # Store the spring stiffness magnitude itself.
                        data_parts.append(np.array([val], dtype=float))
                    else:
                        Ke[m, n] += val

            if node.spring_RX[0] is not None:

                # Check for an active spring support
                if node.spring_RX[2] == True:
                    m, n = node.ID*6 + 3, node.ID*6 + 3
                    # Capture the rotational X-direction spring stiffness.
                    val = float(node.spring_RX[0])
                    if sparse == True:
                        # Store the row index for the RX spring.
                        row_parts.append(np.array([m], dtype=np.int64))
                        # Store the column index for the RX spring.
                        col_parts.append(np.array([n], dtype=np.int64))
                        # Store the rotational stiffness value for RX.
                        data_parts.append(np.array([val], dtype=float))
                    else:
                        Ke[m, n] += val

            if node.spring_RY[0] is not None:

                # Check for an active spring support
                if node.spring_RY[2] == True:
                    m, n = node.ID*6 + 4, node.ID*6 + 4
                    # Capture the rotational Y-direction spring stiffness.
                    val = float(node.spring_RY[0])
                    if sparse == True:
                        # Store the row index for the RY spring.
                        row_parts.append(np.array([m], dtype=np.int64))
                        # Store the column index for the RY spring.
                        col_parts.append(np.array([n], dtype=np.int64))
                        # Store the rotational stiffness value for RY.
                        data_parts.append(np.array([val], dtype=float))
                    else:
                        Ke[m, n] += val

            if node.spring_RZ[0] is not None:

                # Check for an active spring support
                if node.spring_RZ[2] == True:
                    m, n = node.ID*6 + 5, node.ID*6 + 5
                    # Capture the rotational Z-direction spring stiffness.
                    val = float(node.spring_RZ[0])
                    if sparse == True:
                        # Store the row index for the RZ spring.
                        row_parts.append(np.array([m], dtype=np.int64))
                        # Store the column index for the RZ spring.
                        col_parts.append(np.array([n], dtype=np.int64))
                        # Store the rotational stiffness value for RZ.
                        data_parts.append(np.array([val], dtype=float))
                    else:
                        Ke[m, n] += val

        # Add stiffness terms for each spring in the model
        if log: print('- Adding spring stiffness terms to global stiffness matrix')
        for spring in self.springs.values():

            if spring.active[combo_name] == True:

                # Build the DOF index vector once and add the whole 12x12 block in one shot.
                # This mirrors the old nested loops but pushes the work into numpy.
                # Capture the full set of i/j DOF indices for this spring element.
                dofs = self._build_dof_vector(spring.i_node, spring.j_node)
                # Grab the spring's already-transformed global stiffness matrix.
                spring_Ke = spring.Ke()

                if sparse == True:
                    # Convert the spring block into sparse row/col/data pieces.
                    self._append_sparse_block(dofs, spring_Ke, row_parts, col_parts, data_parts)
                else:
                    # Add the spring block directly to the dense global matrix.
                    self._add_dense_block(Ke, dofs, spring_Ke)

        # Add stiffness terms for each physical member in the model
        if log: print('- Adding member stiffness terms to global stiffness matrix')
        for phys_member in self.members.values():

            # Check to see if the physical member is active for the given load combination
            if phys_member.active[combo_name] == True:

                # Step through each sub-member in the physical member and add terms
                for member in phys_member.sub_members.values():

                    # Build the member DOF vector once so we can add the entire 12x12 block,
                    # keeping parity with the previous (i,j) nested summation.
                    # Capture the member's i/j DOFs for subsequent block placement.
                    dofs = self._build_dof_vector(member.i_node, member.j_node)
                    # Grab the member's global stiffness matrix.
                    member_Ke = member.Ke()

                    if sparse == True:
                        # Append the member block into the sparse assembly lists.
                        self._append_sparse_block(dofs, member_Ke, row_parts, col_parts, data_parts)
                    else:
                        # Inject the member block into the dense matrix via vectorized indexing.
                        self._add_dense_block(Ke, dofs, member_Ke)

        # Add stiffness terms for each quadrilateral in the model
        if log: print('- Adding quadrilateral stiffness terms to global stiffness matrix')
        for quad in self.quads.values():

            # Get the quadrilateral's global stiffness matrix
            # Storing it as a local variable eliminates the need to rebuild it every time a term is needed
            quad_Ke = quad.Ke()
            # Four nodes -> 24 DOFs. The helper keeps those indices contiguous so the
            # full block can be added without manual bookkeeping.
            # Build the 24-entry DOF vector for the quadrilateral element.
            dofs = self._build_dof_vector(quad.i_node, quad.j_node, quad.m_node, quad.n_node)

            if sparse == True:
                # Append the quad block contributions to the sparse assembly lists.
                self._append_sparse_block(dofs, quad_Ke, row_parts, col_parts, data_parts)
            else:
                # Add the quad block directly to the dense matrix.
                self._add_dense_block(Ke, dofs, quad_Ke)

        # Add stiffness terms for each plate in the model
        if log: print('- Adding plate stiffness terms to global stiffness matrix')
        for plate in self.plates.values():

            # Get the plate's global stiffness matrix
            # Storing it as a local variable eliminates the need to rebuild it every time a term is needed
            plate_Ke = plate.Ke()
            # Same concept as the quad above, but for the rectangular plate element.
            # Build the DOF vector for the plate's four nodes.
            dofs = self._build_dof_vector(plate.i_node, plate.j_node, plate.m_node, plate.n_node)

            if sparse == True:
                # Append the plate block contributions to the sparse assembly lists.
                self._append_sparse_block(dofs, plate_Ke, row_parts, col_parts, data_parts)
            else:
                # Add the plate block directly to the dense matrix.
                self._add_dense_block(Ke, dofs, plate_Ke)

        if sparse:
            # Concatenate the per-element contributions into the vectors scipy expects.
            if row_parts:
                # Collapse all stored row chunks into one contiguous vector.
                row = np.concatenate(row_parts)
                # Collapse all stored column chunks into one contiguous vector.
                col = np.concatenate(col_parts)
                # Collapse all stored data chunks into one contiguous vector.
                data = np.concatenate(data_parts)
            else:
                # Provide empty row vector when no elements contributed (edge case).
                row = np.array([], dtype=np.int64)
                # Provide empty column vector when no elements contributed (edge case).
                col = np.array([], dtype=np.int64)
                # Provide empty data vector when no elements contributed (edge case).
                data = np.array([], dtype=float)

            # Build the sparse COO matrix from the assembled vectors.
            Ke = sp.sparse.coo_matrix((data, (row, col)), shape=(len(self.nodes)*6, len(self.nodes)*6))

        # Check that there are no nodal instabilities
        if check_stability:
            if log: print('- Checking nodal stability')
            if sparse: Analysis._check_stability(self, Ke.tocsr())
            else: Analysis._check_stability(self, Ke)

        # Return the global elastic stiffness matrix
        return Ke

    def Kg(self, combo_name='Combo 1', log=False, sparse=True, first_step=True):
        """Returns the model's global geometric stiffness matrix. Geometric stiffness of plates is not considered.

        :param combo_name: The name of the load combination to derive the matrix for. Defaults to 'Combo 1'.
        :type combo_name: str, optional
        :param log: Prints updates to the console if set to `True`. Defaults to `False`.
        :type log: bool, optional
        :param sparse: Returns a sparse matrix if set to `True`, and a dense matrix otherwise. Defaults to `True`.
        :type sparse: bool, optional
        :param first_step: Used to indicate if the analysis is occuring at the first load step. Used in nonlinear analysis where the load is broken into multiple steps. Default is `True`.
        :type first_step: bool, optional
        :return: The global geometric stiffness matrix for the structure.
        :rtype: ndarray or coo_matrix
        """

        if sparse == True:
            # The geometric stiffness matrix will be stored as a scipy `coo_matrix`. Scipy's documentation states that this type of matrix is ideal for efficient construction of finite element matrices. When converted to another format, the `coo_matrix` sums values at the same (i, j) index. We'll build the matrix from three lists.
            row, col, data = [], [], []
        else:
            Kg = np.zeros((len(self.nodes)*6, len(self.nodes)*6))

        # Add stiffness terms for each physical member in the model
        if log:
            print('- Adding member geometric stiffness terms to global geometric stiffness matrix')
        for phys_member in self.members.values():

            # Check to see if the physical member is active for the given load combination
            if phys_member.active[combo_name] == True:

                # Step through each sub-member in the physical member and add terms
                for member in phys_member.sub_members.values():

                    # Calculate the axial force in the member
                    E = member.material.E
                    A = member.section.A
                    L = member.L()

                    # Calculate the axial force acting on the member
                    if first_step:
                        # For the first load step take P = 0
                        P = 0
                    else:
                        if self.solution == 'Pushover':
                            # Use the axial force at the current nonlinear/inelastic load step
                            P = member.f_nonlin[combo_name][6] - member.f_nonlin[combo_name][0]
                        else:
                            # Calculate the member axial force due to linear/elastic axial strain
                            d = member.d(combo_name)
                            P = E*A/L*(d[6, 0] - d[0, 0])

                    # Get the member's global stiffness matrix
                    # Storing it as a local variable eliminates the need to rebuild it every time a term is needed
                    member_Kg = member.Kg(P)

                    # Step through each term in the member's stiffness matrix
                    # 'a' & 'b' below are row/column indices in the member's stiffness matrix
                    # 'm' & 'n' are corresponding row/column indices in the global stiffness matrix
                    for a in range(12):

                        # Determine if index 'a' is related to the i-node or j-node
                        if a < 6:
                            # Find the corresponding index 'm' in the global stiffness matrix
                            m = member.i_node.ID*6 + a
                        else:
                            # Find the corresponding index 'm' in the global stiffness matrix
                            m = member.j_node.ID*6 + (a-6)

                        for b in range(12):

                            # Determine if index 'b' is related to the i-node or j-node
                            if b < 6:
                                # Find the corresponding index 'n' in the global stiffness matrix
                                n = member.i_node.ID*6 + b
                            else:
                                # Find the corresponding index 'n' in the global stiffness matrix
                                n = member.j_node.ID*6 + (b-6)

                            # Now that 'm' and 'n' are known, place the term in the global stiffness matrix
                            if sparse == True:
                                row.append(m)
                                col.append(n)
                                data.append(member_Kg[(a, b)])
                            else:
                                Kg[m, n] += member_Kg[(a, b)]

        if sparse:
            # Convert the row, col, data lists to numpy arrays and create the COO matrix
            row = np.array(row)
            col = np.array(col)
            data = np.array(data)
            Kg = sp.sparse.coo_matrix((data, (row, col)), shape=(len(self.nodes)*6, len(self.nodes)*6))

        # Return the global geometric stiffness matrix
        return Kg

    def Km(self, combo_name='Combo 1', push_combo='Push', step_num=1, log=False, sparse=True):
        """Calculates the structure's global plastic reduction matrix, which is used for nonlinear inelastic analysis.

        :param combo_name: The name of the load combination to get the plastic reduction matrix for. Defaults to 'Combo 1'.
        :type combo_name: str, optional
        :param push_combo: The name of the load combination that contains the pushover load definition. Defaults to 'Push'.
        :type push_combo: str, optional
        :param step_num: The load step used to generate the plastic reduction matrix. Defaults to 1.
        :type step_num: int, optional
        :param log: Determines whether this method writes output to the console as it runs. Defaults to False.
        :type log: bool, optional
        :param sparse: Indicates whether the sparse solver should be used. Defaults to True.
        :type sparse: bool, optional
        :return: The global plastic reduction matrix.
        :rtype: np.array
        """

        # Determine if a sparse matrix has been requested
        if sparse == True:
            # The plastic reduction matrix will be stored as a scipy `coo_matrix`. Scipy's documentation states that this type of matrix is ideal for efficient construction of finite element matrices. When converted to another format, the `coo_matrix` sums values at the same (i, j) index. We'll build the matrix from three lists.
            row = []
            col = []
            data = []
        else:
            # Initialize a dense matrix of zeros
            Km = np.zeros((len(self.nodes)*6, len(self.nodes)*6))

        # Add stiffness terms for each physical member in the model
        for phys_member in self.members.values():

            # Check to see if the physical member is active for the given load combination
            if phys_member.active[combo_name] == True:

                # Step through each sub-member in the physical member and add terms
                for member in phys_member.sub_members.values():

                    # Get the member's global plastic reduction matrix
                    # Storing it as a local variable eliminates the need to rebuild it every time a term is needed
                    member_Km = member.Km(combo_name)

                    # Step through each term in the member's plastic reduction matrix
                    # 'a' & 'b' below are row/column indices in the member's matrix
                    # 'm' & 'n' are corresponding row/column indices in the structure's global matrix
                    for a in range(12):

                        # Determine if index 'a' is related to the i-node or j-node
                        if a < 6:
                            # Find the corresponding index 'm' in the global plastic reduction matrix
                            m = member.i_node.ID*6 + a
                        else:
                            # Find the corresponding index 'm' in the global plastic reduction matrix
                            m = member.j_node.ID*6 + (a-6)

                        for b in range(12):

                            # Determine if index 'b' is related to the i-node or j-node
                            if b < 6:
                                # Find the corresponding index 'n' in the global plastic reduction matrix
                                n = member.i_node.ID*6 + b
                            else:
                                # Find the corresponding index 'n' in the global plastic reduction matrix
                                n = member.j_node.ID*6 + (b-6)

                            # Now that 'm' and 'n' are known, place the term in the global plastic reduction matrix
                            if sparse == True:
                                row.append(m)
                                col.append(n)
                                data.append(member_Km[a, b])
                            else:
                                Km[m, n] += member_Km[a, b]

        if sparse:
            # The plastic reduction matrix will be stored as a scipy `coo_matrix`. Scipy's documentation states that this type of matrix is ideal for efficient construction of finite element matrices. When converted to another format, the `coo_matrix` sums values at the same (i, j) index.
            row = np.array(row)
            col = np.array(col)
            data = np.array(data)
            Km = sp.sparse.coo_matrix((data, (row, col)), shape=(len(self.nodes)*6, len(self.nodes)*6))

        # Check that there are no nodal instabilities
        # if check_stability:
        #     if log: print('- Checking nodal stability')
        #     if sparse: Analysis._check_stability(self, Km.tocsr())
        #     else: Analysis._check_stability(self, Km)

        # Return the global plastic reduction matrix
        return Km

    def _calculate_characteristic_length(self) -> float:
        """
        Calculates a characteristic length for the model.
        Uses average member length, or bounding box dimensions as fallback.
        """
        if self.members:
            # Use average member length
            total_length = sum(member.L() for member in self.members.values())
            return total_length / len(self.members)
        else:
            # Fallback: use bounding box diagonal
            if self.nodes:
                coords = [(node.X, node.Y, node.Z) for node in self.nodes.values()]
                min_coords = [min(coord[i] for coord in coords) for i in range(3)]
                max_coords = [max(coord[i] for coord in coords) for i in range(3)]
                bbox_diag = sum((max_coords[i] - min_coords[i])**2 for i in range(3))**0.5
                return bbox_diag
            else:
                return 1.0  # Default fallback

    def M(self, mass_combo_name: str | None = None, mass_direction: str = 'Y', gravity: float = 1.0, log: bool = False, sparse: bool = True):
        """
        Returns the model's global mass matrix for dynamic analysis. This implementation follows a separation of responsibilities approach, where members handle both translational and rotational mass/inertia, while nodes provide translational mass only (to prevent double-counting). Rotational stability terms are only added to free DOFs considering member releases and node supports.

        :param mass_combo_name: Load combination name defining mass (via force loads). Forces are converted to mass using m = F/g. If `None` is specified, masses from loads will be ignored during modal analysis. Defaults to `None`.
        :type mass_combo_name: str, optional
        :param mass_direction: Direction for load-to-mass conversion ('X', 'Y', or 'Z'). Any loads applied in this direction (positive or negative) will be converted to mass. Default is 'Y'.
        :type mass_direction: str, optional
        :param gravity: The acceleration due to gravity. Defaults to 1.0. In most cases you'll want to change this to be in units consistent with your model.
        :type gravity: float
        :param log: Whether to print progress messages, defaults to `False`.
        :type log: bool, optional
        :param sparse: Whether to return a sparse matrix, defaults to `True`.
        :type sparse: bool, optional
        :return: Global mass matrix of shape (n_dof, n_dof)
        :rtype: scipy.sparse.coo_matrix or numpy.ndarray
        """

        # TODO: Change gravity direction inputs to accept X, Y and Z instead of 0, 1, and 2.

        # Check if a sparse matrix has been requested
        if sparse == True:
            # Reuse the same block-based storage approach used for the stiffness matrix.
            # Initialize list to collect row index vectors per element for mass assembly.
            row_parts: list[np.ndarray] = []
            # Initialize list to collect column index vectors per element for mass assembly.
            col_parts: list[np.ndarray] = []
            # Initialize list to collect data vectors per element for mass assembly.
            data_parts: list[np.ndarray] = []
        else:
            # Initialize a dense matrix of zeros
            M = np.zeros((len(self.nodes)*6, len(self.nodes)*6))

        if log:
            print(f' - Converting member loads from combo: {mass_combo_name} into masses.')

        # Step through each physical member in the model
        for phys_member in self.members.values():

            # Determine if this physical member is active
            if phys_member.active[mass_combo_name] == True:

                # Step through each submember in this physical member
                for member in phys_member.sub_members.values():

                    member_M = member.M(mass_combo_name, mass_direction, gravity)
                    # Reuse the same DOF layout as stiffness assembly so mass and stiffness
                    # stay aligned term-by-term.
                    # Build the DOF vector shared with stiffness for consistency.
                    dofs = self._build_dof_vector(member.i_node, member.j_node)

                    if sparse:
                        # Append the member mass block into the sparse lists.
                        self._append_sparse_block(dofs, member_M, row_parts, col_parts, data_parts)
                    else:
                        # Inject the member mass block into the dense matrix.
                        self._add_dense_block(M, dofs, member_M)

        if log:
            print(f' - Converting nodal loads from combo: {mass_combo_name} to mass (translation only)')

        # Step through each node in the model
        for node in self.nodes.values():

            # Get node's mass matrix (translation only, so set characteristic length to `None`)
            node_m = node.M(mass_combo_name, mass_direction, gravity, characteristic_length=None)

            # Node-only mass contributes translational DOFs. The helper still works even
            # though only one node is supplied.
            # Build the DOF vector for this single node's translational DOFs.
            dofs = self._build_dof_vector(node)

            if sparse:
                # Append the nodal mass block into the sparse lists.
                self._append_sparse_block(dofs, node_m, row_parts, col_parts, data_parts)
            else:
                # Add the nodal mass block directly into the dense matrix.
                self._add_dense_block(M, dofs, node_m)

        # Add sparse option
        if sparse:
            if row_parts:
                # Concatenate all row vectors contributed by members and nodes.
                row = np.concatenate(row_parts)
                # Concatenate all column vectors contributed by members and nodes.
                col = np.concatenate(col_parts)
                # Concatenate all data vectors contributed by members and nodes.
                data = np.concatenate(data_parts)
            else:
                # Provide empty row vector when no mass contributions exist.
                row = np.array([], dtype=np.int64)
                # Provide empty column vector when no mass contributions exist.
                col = np.array([], dtype=np.int64)
                # Provide empty data vector when no mass contributions exist.
                data = np.array([], dtype=float)

            # Build the sparse COO mass matrix from the assembled vectors.
            M = sp.sparse.coo_matrix((data, (row, col)), shape=(len(self.nodes)*6, len(self.nodes)*6))

        # At this point, we have M, but there could be zero terms along the diagonal indicating DOFs without mass. We'll add an insignificant mass to those terms to get the matrix to solve.

        # Get all the diagonal terms from the mass matrix
        if sparse:
            Mdiag = M.diagonal()
        else:
            Mdiag = np.diag(M)

        # Get all the diagonal terms that are greater than zero
        positive = Mdiag[Mdiag > 0]

        # Calculate a mass that will be insignificant to the overall solution
        if positive.size > 0:
            eps = positive.min()*1e-6  # tiny stabilization mass
        else:
            raise Exception('Unable to perform modal analysis. Model is massless.')  # Fallback for truly massless models

        # Identify which terms on the diagonal have zero mass
        zero_diag = (Mdiag == 0)

        # Add our tiny stabilization mass to these terms
        if sparse:
            # Add eps to zero-mass DOFs
            M = M + sp.sparse.diags(eps*zero_diag.astype(float), 0, shape=M.shape)
        else:
            idx = np.where(zero_diag)[0]
            M[idx, idx] += eps

        if log:
            print('- Global mass matrix complete')

        return M

    def FER(self, combo_name='Combo 1') -> NDArray[float64]:
        """Assembles and returns the global fixed end reaction vector for any given load combo.

        :param combo_name: The name of the load combination to get the fixed end reaction vector
                           for. Defaults to 'Combo 1'.
        :type combo_name: str, optional
        :return: The fixed end reaction vector
        :rtype: NDArray[float64]
        """

        # Initialize a zero vector to hold all the terms
        FER = np.zeros((len(self.nodes) * 6, 1))

        # Step through each physical member in the model; each sub-member reports a 12x1 block
        # that already lives in global coordinates, so we can drop it straight onto the matching
        # DOFs without touching individual entries.
        for phys_member in self.members.values():

            # Step through each sub-member and add terms
            for member in phys_member.sub_members.values():

                # Grab the member's fixed-end reactions and add the entire 12x1 block
                # directly at the matching DOF locations. Casting/reshaping makes sure we have
                # a flat float vector that aligns with the DOF helper ordering.
                member_FER = np.asarray(member.FER(combo_name), dtype=float).reshape(-1)
                dofs = self._build_dof_vector(member.i_node, member.j_node)
                FER[dofs, 0] += member_FER

        # Repeat the same block-based add for rectangular plates (24x1 reaction blocks).
        for plate in self.plates.values():

            # Add the 24x1 plate reactions with the same DOF helper used for stiffness/mass so
            # the indexing stays consistent across every assembler.
            plate_FER = np.asarray(plate.FER(combo_name), dtype=float).reshape(-1)
            dofs = self._build_dof_vector(plate.i_node, plate.j_node, plate.m_node, plate.n_node)
            FER[dofs, 0] += plate_FER

        # Quadrilaterals follow the same pattern: 24x1 block dropped in via the DOF helper.
        for quad in self.quads.values():

            # Add the 24x1 quad reactions in a single vectorized write via the DOF helper.
            quad_FER = np.asarray(quad.FER(combo_name), dtype=float).reshape(-1)
            dofs = self._build_dof_vector(quad.i_node, quad.j_node, quad.m_node, quad.n_node)
            FER[dofs, 0] += quad_FER

        # Return the global fixed end reaction vector
        return FER

    def P(self, combo_name='Combo 1') -> NDArray[float64]:
        """Assembles and returns the global nodal force vector.

        :param combo_name: The name of the load combination to get the force vector for. Defaults
                           to 'Combo 1'.
        :type combo_name: str, optional
        :return: The global nodal force vector.
        :rtype: NDArray[float64]
        """

        # Initialize a zero vector to hold all the terms
        P = np.zeros((len(self.nodes)*6, 1))

        # Get the load combination for the given 'combo_name'
        combo = self.load_combos[combo_name]

        # Map load direction strings to their DOF offsets once so we do not re-run the
        # if/elif ladder for every single nodal load.
        dof_lookup = {'FX': 0, 'FY': 1, 'FZ': 2, 'MX': 3, 'MY': 4, 'MZ': 5}

        # Add terms for each node in the model
        for node in self.nodes.values():

            # Accumulate this node's six DOF loads locally before writing to the global vector.
            # This keeps the code vectorized and avoids hammering the global array for every
            # individual load tuple.
            local = np.zeros(6, dtype=float)

            for direction, magnitude, case in node.NodeLoads:
                # Look up the combo factor once per load; loads from unrelated cases are skipped
                # immediately instead of falling through nested conditionals.
                factor = combo.factors.get(case)
                if factor is None:
                    continue

                # Normalize the direction string and map it to the correct DOF slot. Unknown
                # direction labels are ignored to match the previous behavior.
                idx = dof_lookup.get(direction.upper())
                if idx is None:
                    continue  # Ignore load types outside the standard 6 DOFs

                # Add the scaled load into the local 6-entry accumulator.
                local[idx] += factor * magnitude

            # Once all loads for this node are tallied, drop the 6x1 block into the global
            # vector via the DOF helper. Empty accumulators are skipped to avoid pointless writes.
            if np.any(local):
                dofs = self._build_dof_vector(node)
                P[dofs, 0] += local

        # Return the global nodal force vector
        return P

    def D(self, combo_name='Combo 1') -> NDArray[float64]:
        """Returns the global displacement vector for the model.

        :param combo_name: The name of the load combination to get the results for. Defaults to
                           'Combo 1'.
        :type combo_name: str, optional
        :return: The global displacement vector for the model
        :rtype: NDArray[float64]
        """

        # Return the global displacement vector
        return self._D[combo_name]

    def analyze_linear(self, log=False, check_stability=True, check_statics=False, sparse=True, combo_tags=None):
        """Performs first-order static analysis. This analysis procedure is much faster since it only assembles the global stiffness matrix once, rather than once for each load combination. It is not appropriate when non-linear behavior such as tension/compression only analysis or P-Delta analysis are required.

        :param log: Prints the analysis log to the console if set to True. Default is False.
        :type log: bool, optional
        :param check_stability: When set to True, checks the stiffness matrix for any unstable degrees of freedom and reports them back to the console. This does add to the solution time. Defaults to True.
        :type check_stability: bool, optional
        :param check_statics: When set to True, causes a statics check to be performed. Defaults to False.
        :type check_statics: bool, optional
        :param sparse: Indicates whether the sparse matrix solver should be used. A matrix can be considered sparse or dense depening on how many zero terms there are. Structural stiffness matrices often contain many zero terms. The sparse solver can offer faster solutions for such matrices. Using the sparse solver on dense matrices may lead to slower solution times. Be sure ``scipy`` is installed to use the sparse solver. Default is True.
        :type sparse: bool, optional
        :raises Exception: Occurs when a singular stiffness matrix is found. This indicates an unstable structure has been modeled.
        """

        if log:
            print('+-------------------+')
            print('| Analyzing: Linear |')
            print('+-------------------+')

        # Prepare the model for analysis
        Analysis._prepare_model(self)

        # Get the auxiliary list used to determine how the matrices will be partitioned
        D1_indices, D2_indices, D2 = Analysis._partition_D(self)

        # Get the partitioned global stiffness matrix K11, K12, K21, K22
        # Note that for linear analysis the stiffness matrix can be obtained for any load combination, as it's the same for all of them
        combo_name = list(self.load_combos.keys())[0]
        if sparse == True:
            K11, K12, K21, K22 = Analysis._partition(self, self.Ke(combo_name, log, check_stability, sparse).tocsr(), D1_indices, D2_indices)
        else:
            K11, K12, K21, K22 = Analysis._partition(self, self.Ke(combo_name, log, check_stability, sparse), D1_indices, D2_indices)

        # Identify which load combinations have the tags the user has given
        combo_list = Analysis._identify_combos(self, combo_tags)

        # Step through each load combination
        for combo in combo_list:

            if log:
                print('')
                print('- Analyzing load combination ' + combo.name)

            # Get the partitioned global fixed end reaction vector
            FER1, FER2 = Analysis._partition(self, self.FER(combo.name), D1_indices, D2_indices)

            # Get the partitioned global nodal force vector
            P1, P2 = Analysis._partition(self, self.P(combo.name), D1_indices, D2_indices)

            # Calculate the global displacement vector
            if log:
                print('- Calculating global displacement vector')
            if K11.shape == (0, 0):
                # All displacements are known, so D1 is an empty vector
                D1 = []
            else:
                # Calculate the unknown displacements D1. The partitioned stiffness matrix
                # originates as `coo` and is converted to `csr`/`csc` for mathematical
                # operations. `_solve_unknown_disp` also detects global instability (a singular
                # matrix) that the bare solvers can silently miss.
                if sparse == True:
                    rhs = np.subtract(np.subtract(P1, FER1), K12.tocsr() @ D2)
                else:
                    rhs = np.subtract(np.subtract(P1, FER1), np.matmul(K12, D2))
                D1 = Analysis._solve_unknown_disp(K11, rhs, sparse, check_stability)

            # Store the calculated displacements to the model and the nodes in the model
            Analysis._store_displacements(self, D1, D2, D1_indices, D2_indices, combo)

        # Calculate reactions
        Analysis._calc_reactions(self, log, combo_tags)

        if log:
            print('')
            print('- Analysis complete')
            print('')

        # Check statics if requested
        if check_statics == True:
            Analysis._check_statics(self, combo_tags)

        # Flag the model as solved
        self.solution = 'Linear'

    def analyze(self, log=False, check_stability=True, check_statics=False, max_iter=30, sparse=True, combo_tags=None, spring_tolerance=0, member_tolerance=0, num_steps=1):
        """Performs a first-order elastic analysis of the model.

        Allows sparse solvers for larger models, handles tension/compression-only
        behavior for nodal springs and members via iteration, and supports load
        stepping for improved convergence.

        :param log: If ``True``, prints progress messages during analysis. Defaults to ``False``.
        :type log: bool, optional
        :param check_stability: If ``True``, checks model stability at each analysis step. Defaults to ``True``.
        :type check_stability: bool, optional
        :param check_statics: If ``True``, performs a statics check after analysis. Defaults to ``False``.
        :type check_statics: bool, optional
        :param max_iter: Maximum number of tension/compression-only iterations allowed per load step before assuming divergence. Defaults to ``30``.
        :type max_iter: int, optional
        :param sparse: If ``True``, uses sparse matrix solvers for improved efficiency on large models. Defaults to ``True``.
        :type sparse: bool, optional
        :param combo_tags: Tags used to select which load combinations to analyze. If ``None``, all combinations are analyzed. Defaults to ``None``.
        :type combo_tags: list[str] | None, optional
        :param spring_tolerance: Convergence tolerance for springs in tension/compression-only analysis. Defaults to ``0``.
        :type spring_tolerance: float, optional
        :param member_tolerance: Convergence tolerance for members in tension/compression-only analysis. Defaults to ``0``.
        :type member_tolerance: float, optional
        :param num_steps: Number of load increments for applying load combinations. Use more steps for better convergence in highly nonlinear cases. Defaults to ``1``.
        :type num_steps: int, optional
        :raises Exception: If the stiffness matrix is singular (indicating instability) or if the model fails to converge within the maximum allowed iterations.
        """

        if log:
            print('+-----------+')
            print('| Analyzing |')
            print('+-----------+')

        # Import `scipy` features if the sparse solver is being used
        if sparse == True:
            from scipy.sparse.linalg import spsolve

        # Prepare the model for analysis
        Analysis._prepare_model(self)

        # Identify which load combinations have the tags the user has given
        combo_list = Analysis._identify_combos(self, combo_tags)

        # Get the auxiliary list used to determine how the matrices will be partitioned
        D1_indices, D2_indices, D2 = Analysis._partition_D(self)

        # Calculate the incremental enforced displacement vector
        Delta_D2 = D2/num_steps

        # Step through each load combination
        for combo in combo_list:

            if log:
                print('')
                print('- Analyzing load combination ' + combo.name)

            # Get the partitioned total global fixed end reaction vector
            FER1, FER2 = Analysis._partition(self, self.FER(combo.name), D1_indices, D2_indices)

            # Get the partitioned total global nodal force vector
            P1, P2 = Analysis._partition(self, self.P(combo.name), D1_indices, D2_indices)

            # Run the shared first-order solution path for this load combination
            Analysis._first_order(self, combo.name, P1, FER1, D1_indices, D2_indices, D2,
                                  log, sparse, check_stability, max_iter,
                                  spring_tolerance, member_tolerance, num_steps)

        # Calculate reactions
        Analysis._calc_reactions(self, log, combo_tags)

        if log:
            print('')
            print('- Analysis complete')
            print('')

        # Check statics if requested
        if check_statics == True:
            Analysis._check_statics(self, combo_tags)

    def analyze_PDelta(self, log=False, check_stability=True, max_iter=30, sparse=True, combo_tags=None):
        """Performs second order (P-Delta) analysis. This type of analysis is appropriate for most models using beams, columns and braces. Second order analysis is usually required by material specific codes. The analysis is iterative and takes longer to solve. Models with slender members and/or members with combined bending and axial loads will generally have more significant P-Delta effects. P-Delta effects in plates/quads are not considered.

        :param log: Prints updates to the console if set to True. Default is False.
        :type log: bool, optional
        :param check_stability: When set to True, checks the stiffness matrix for any unstable degrees of freedom and reports them back to the console. This does add to the solution time. Defaults to True.
        :type check_stability: bool, optional
        :param max_iter: The maximum number of iterations permitted. If this value is exceeded the program will report divergence. Defaults to 30.
        :type max_iter: int, optional
        :param sparse: Indicates whether the sparse matrix solver should be used. A matrix can be considered sparse or dense depening on how many zero terms there are. Structural stiffness matrices often contain many zero terms. The sparse solver can offer faster solutions for such matrices. Using the sparse solver on dense matrices may lead to slower solution times. Be sure ``scipy`` is installed to use the sparse solver. Default is True.
        :type sparse: bool, optional
        :raises ValueError: Occurs when there is a singularity in the stiffness matrix, which indicates an unstable structure.
        :raises Exception: Occurs when a model fails to converge.
        """

        if log:
            print('+--------------------+')
            print('| Analyzing: P-Delta |')
            print('+--------------------+')

        # Import `scipy` features if the sparse solver is being used
        if sparse == True:
            from scipy.sparse.linalg import spsolve

        # Prepare the model for analysis
        Analysis._prepare_model(self)

        # Get the auxiliary list used to determine how the matrices will be partitioned
        D1_indices, D2_indices, D2 = Analysis._partition_D(self)

        # Identify which load combinations have the tags the user has given
        combo_list = Analysis._identify_combos(self, combo_tags)

        # Step through each load combination
        for combo in combo_list:

            # Get the partitioned global fixed end reaction vector
            FER1, FER2 = Analysis._partition(self, self.FER(combo.name), D1_indices, D2_indices)

            # Get the partitioned global nodal force vector
            P1, P2 = Analysis._partition(self, self.P(combo.name), D1_indices, D2_indices)

            # Run the P-Delta analysis for this load combination
            Analysis._PDelta(self, combo.name, P1, FER1, D1_indices, D2_indices, D2, log, sparse, check_stability, max_iter)

        # Calculate reactions
        Analysis._calc_reactions(self, log, combo_tags)

        if log:
            print('')
            print('- Analysis complete')
            print('')

        # Flag the model as solved
        self.solution = 'P-Delta'

    def analyze_modal(self, num_modes: int = 12, mass_combo_name: str = 'Combo 1', mass_direction: str = 'Y', gravity: float = 1.0, log=False, check_stability=True):
        """
        Performs modal analysis to determine natural frequencies and mode shapes.

        A sparse solution based on `num_modes` is always used to help filter out irrelevant frequencies from unimportant modes.

        :param num_modes: Number of modes to calculate. Defaults to 12.
        :type num_modes: int, optional
        :param mass_combo_name: Load combination name to use to convert loads to masses. Defaults to `Combo 1`.
        :type mass_combo_name: str, optional
        :param mass_direction: Direction for load-to-mass conversion ('X', 'Y', or 'Z'). Any loads applied in this direction (postive or negative) will be converted to mass. Defaults to 'Y'.
        :type mass_direction: str, optional
        :param gravity: The acceleration due to gravity. Defaults to 1.0. In most cases you'll want to change this to be in units consistent with your model.
        :type gravity: float
        :param log: Prints the analysis log to the console if set to True. Default is False.
        :type log: bool, optional
        :param check_stability: When set to True, checks the stiffness matrix for unstable DOFs. Defaults to True.
        :type check_stability: bool, optional
        :return: A list containing frequencies (Hz)
        :rtype: List
        :raises Exception: Occurs when a singular stiffness matrix is found.
        """

        if log:
            print('+------------------+')
            print('| Analyzing: Modal |')
            print('+------------------+')

        # Prepare the model for analysis (same as other analysis methods)
        # This will generate the default load case ('Case 1') and load combo ('Combo 1') if none are present.
        Analysis._prepare_model(self, num_modes)

        # Get the auxiliary list used for matrix partitioning
        D1_indices, D2_indices, D2 = Analysis._partition_D(self)

        if log:
            print('- Assembling global stiffness matrix')

        # Assemble and partition the global stiffness matrix
        Ke_global = self.Ke(mass_combo_name, log, check_stability, sparse=True).tocsr()

        # Partition to remove supported DOFs
        K11, K12, K21, K22 = Analysis._partition(self, Ke_global, D1_indices, D2_indices)

        if log:
            print('- Assembling global mass matrix')

        # Assemble and partition the global mass matrix
        M_global = self.M(mass_combo_name, mass_direction, gravity, log, sparse=True).tocsr()

        # Partition to remove supported DOFs
        M11, M12, M21, M22 = Analysis._partition(self, M_global, D1_indices, D2_indices)

        # Check that we have mass terms
        if M11.nnz == 0:
            raise Exception('No mass terms found. Ensure materials have density or provide mass_combo_name.')

        if log:
            print('- Solving eigenvalue problem')

        try:
            # Solve the generalized eigenvalue problem: [K11]{φ} = λ[M11]{φ}, where λ = ω²
            # Or rewritten: (-[M11]ω² + [K11]){φ} = 0
            # (See "Structural Dynamics for Structural Engineers" by Hart & Wong Equation 4.96)
            eigenvalues, eigenvectors = sp.sparse.linalg.eigsh(A=K11, k=num_modes, M=M11, sigma=0.0, which='LM')

        except sp.linalg.LinAlgError as e:
            raise Exception(f'Eigenvalue solution failed: {str(e)}. Check matrix conditioning.')

        # Calculate frequencies in Hz from eigenvalues (λ = ω²)
        frequencies = np.sqrt(eigenvalues) / (2 * np.pi)

        if log:
            print('- Processing mode shapes')

        # Process eigenvectors (mode shapes) to expand back to full DOF set
        for i in range(len(frequencies)):

            # Get the load combo for this mode
            mode_combo = self.load_combos[f'Mode {i + 1}']

            # Reshape the SciPy eigenvector (mode shape) into a column array that is compatible with Pynite
            D1_mode = eigenvectors[:, i].reshape(-1, 1)

            Analysis._store_displacements(self, D1_mode, D2, D1_indices, D2_indices, mode_combo)

        # Store results in the model
        self.frequencies = frequencies

        if log:
            print('- Modal analysis complete')

        # Flag the model as having modal results
        self.solution = 'Modal'

        if log:
            print(f'- Found {len(frequencies)} modes')
            for i, freq in enumerate(frequencies):
                print(f'  Mode {i + 1}: {freq:.3f} Hz')
            print('- Modal analysis complete')

# %%
    # Pushover results/query methods live with the pushover solver for locality.
    def get_pushover_trace(self, combo_name, trace_name):
        """Returns the recorded history for a named pushover trace."""

        return self._pushover_traces[combo_name][trace_name]

    def plot_pushover_trace(self, trace_name, combo_name=None, combo_names=None, ax=None, filepath=None, dpi=150):
        """Plots and saves a pushover trace by accepted step number for one load combo or an envelope."""

        import matplotlib.pyplot as plt

        if combo_name is None and combo_names is None:
            raise ValueError('Either combo_name or combo_names must be specified for pushover trace plotting.')

        if combo_name is not None and combo_names is not None:
            raise ValueError('Specify either combo_name or combo_names, but not both.')

        created_axes = ax is None

        if ax is None:
            fig, ax = plt.subplots()
        else:
            fig = ax.figure

        if combo_name is not None:
            trace = self.get_pushover_trace(combo_name, trace_name)
            steps = list(range(1, len(trace) + 1))

            ax.plot(steps, trace, linewidth=2, label=combo_name)
            title = f'{trace_name} - {combo_name}'
            default_name = f'{trace_name}_{combo_name}_pushover_trace.png'

        else:
            combo_names = list(combo_names)
            if not combo_names:
                raise ValueError('combo_names must contain at least one load combination name.')

            max_steps = max(len(self.get_pushover_trace(name, trace_name)) for name in combo_names)
            steps = []
            lower = []
            upper = []

            for step_index in range(max_steps):
                values = []

                for name in combo_names:
                    trace = self.get_pushover_trace(name, trace_name)
                    if step_index < len(trace):
                        values.append(trace[step_index])

                if values:
                    steps.append(step_index + 1)
                    lower.append(min(values))
                    upper.append(max(values))

            ax.plot(steps, lower, linewidth=1.5, linestyle='--', label='Envelope min')
            ax.plot(steps, upper, linewidth=1.5, label='Envelope max')
            ax.fill_between(steps, lower, upper, alpha=0.2)
            title = f'{trace_name} envelope'
            default_name = f'{trace_name}_pushover_trace_envelope.png'

        ax.set_xlabel('Step Number')
        ax.set_ylabel(trace_name)
        ax.set_title(title)
        ax.grid(True, alpha=0.3)
        ax.legend()

        if filepath is None:
            save_path = Path.cwd()/default_name
        else:
            save_path = Path(filepath)

        save_path = save_path.resolve()
        fig.tight_layout()
        fig.savefig(save_path, dpi=dpi)

        if created_axes:
            plt.show()

        return fig, ax, save_path

    def analyze_pushover(self, log=False, check_stability=True, push_combo='Push', max_iter=30, tol=0.01, sparse=True, combo_tags=None, control_node=None, control_direction='DX', control_limit=None, traces=None, P_Delta=False):
        """Performs a pushover analysis with optional second-order P-Delta effects.

        By default, the initial preload state is established using first-order analysis and the
        incremental pushover steps omit the geometric stiffness matrix. Set ``P_Delta=True`` to
        opt into second-order behavior for both the preload and the subsequent pushover steps.

        :param log: Prints updates to the console if set to True. Default is False.
        :type log: bool, optional
        :param check_stability: Checks the stiffness matrix for unstable degrees of freedom when
                                set to True. Defaults to True.
        :type check_stability: bool, optional
        :param push_combo: The load combination containing the pushover increment. Defaults to 'Push'.
        :type push_combo: str, optional
        :param max_iter: The maximum number of iterations permitted for the preload solver and
                 the maximum number of retries permitted for each pushover load step.
                 Defaults to 30.
        :type max_iter: int, optional
        :param tol: Convergence tolerance for pushover step validation checks. Defaults to 0.01.
        :type tol: float, optional
        :param sparse: Indicates whether the sparse solver should be used. Defaults to True.
        :type sparse: bool, optional
        :param combo_tags: Tags used to select which primary load combinations to run.
        :type combo_tags: list[str] | None, optional
        :param control_node: Optional node used to stop the pushover once a target displacement is reached.
        :type control_node: str | None, optional
        :param control_direction: Degree of freedom to monitor at the control node.
        :type control_direction: str, optional
        :param control_limit: Optional displacement/rotation limit at the control node.
        :type control_limit: float | None, optional
        :param traces: Optional dictionary of trace names mapped to callables that accept combo_name.
        :type traces: dict | None, optional
        :param P_Delta: Set to True to include geometric stiffness and second-order effects during
                pushover analysis. Defaults to False.
        :type P_Delta: bool, optional
        """

        if control_limit is not None and control_node is None:
            raise ValueError('A control node must be specified when a pushover control limit is provided.')

        if control_direction.upper() not in ('DX', 'DY', 'DZ', 'RX', 'RY', 'RZ'):
            raise ValueError("Pushover control direction must be one of 'DX', 'DY', 'DZ', 'RX', 'RY', or 'RZ'.")

        if max_iter < 1:
            raise ValueError('max_iter must be at least 1 for pushover analysis.')

        if control_node is not None and control_node not in self.nodes:
            raise ValueError(f"Control node '{control_node}' was not found in the model.")

        if traces is not None:
            if not isinstance(traces, dict):
                raise ValueError('Pushover traces must be provided as a dictionary of trace names to callables.')

            for trace_name, trace in traces.items():
                if not callable(trace):
                    raise ValueError(
                        f"Pushover trace '{trace_name}' is not callable. Wrap expressions in a lambda or function that accepts combo_name."
                    )

        if log:
            print('+---------------------+')
            print('| Analyzing: Pushover |')
            print('+---------------------+')

        # Prepare the model for analysis
        Analysis._prepare_model(self)

        # Get the auxiliary list used to determine how the matrices will be partitioned
        D1_indices, D2_indices, D2 = Analysis._partition_D(self)

        # Identify and tag the primary load combinations the pushover load will be added to
        for combo in self.load_combos.values():

            # No need to tag the pushover combo
            if combo.name != push_combo:

                # Add 'primary' to the combo's tags if it's not already there
                if combo.combo_tags is None:
                    combo.combo_tags = ['primary']
                elif 'primary' not in combo.combo_tags:
                    combo.combo_tags.append('primary')

        # Identify which load combinations have the tags the user has given
        combo_list = Analysis._identify_combos(self, combo_tags)
        combo_list = [combo for combo in combo_list if combo.name != push_combo]

        # Initialize per-combo pushover result state.
        self._pushover_state = {}
        self._pushover_traces = {}
        self._pushover_P_Delta = P_Delta

        # Step through each load combination
        for combo in combo_list:

            if log:
                print('')
                print('- Analyzing load combination ' + combo.name)

            # Member end forces will be summed across multiple load steps
            # Set member end force summations to zero
            for phys_member in self.members.values():
                for sub_member in phys_member.sub_members.values():
                    sub_member.f_nonlin = {}

            # Get the partitioned global fixed end reaction vector for the load combination
            FER1, FER2 = Analysis._partition(self, self.FER(combo.name), D1_indices, D2_indices)

            # Get the partitioned global nodal force vector for the load combination
            P1, P2 = Analysis._partition(self, self.P(combo.name), D1_indices, D2_indices)

            # Preload the primary load combination before any pushover increments are applied.
            # By default, pushover uses the first-order analysis path. Set `P_Delta=True` to opt
            # into a second-order preload state.
            if log:
                print('- Preloading the primary combination using ' + ('P-Delta' if P_Delta else 'first-order') + ' analysis')

            if P_Delta:
                Analysis._PDelta(self, combo.name, P1, FER1, D1_indices, D2_indices, D2, False, sparse, check_stability, max_iter)
            else:
                Analysis._first_order(self, combo.name, P1, FER1, D1_indices, D2_indices, D2, False, sparse, check_stability, max_iter)

            # Seed the nonlinear end-force history with the elastic preload state from the
            # primary load combination before any pushover increments are applied.
            for phys_member in self.members.values():
                for sub_member in phys_member.sub_members.values():
                    f = sub_member.f(combo.name)
                    sub_member.f_nonlin[combo.name] = f.reshape(12)

            # The P-Delta analysis above flagged the solution as a P-Delta solution, but we need to
            # indicate that this is actually a Pushover solution so that the calls to Member3D.f()
            # or Member3D._fer_unc() going forward are executed considering nonlinear behavior
            self.solution = 'Pushover'

            # Define the pushover load step and initialize the pushover load factor
            load_step = list(self.load_combos[push_combo].factors.values())[0]
            step_num = 1
            load_factor = load_step*step_num

            # Get the partitioned global fixed end reaction vector for one pushover increment.
            # The pushover combo factor already defines the increment size.
            FER1_push, FER2_push = Analysis._partition(self, self.FER(push_combo), D1_indices, D2_indices)

            # Get the partitioned global nodal force vector for one pushover increment.
            P1_push, P2_push = Analysis._partition(self, self.P(push_combo), D1_indices, D2_indices)

            self._pushover_traces[combo.name] = {
                trace_name: [] for trace_name in (traces or {})
            }

            # Initialize the pushover state for this load combination, which will be updated at
            # each load step and can be queried for results during or after the pushover analysis.
            self._pushover_state[combo.name] = {
                'push_combo': push_combo,
                'P_Delta': P_Delta,
                'status': 'running',
                'step_num': 0,
                'load_factor': 0.0,
                'control_node': control_node,
                'control_direction': control_direction.upper(),
                'control_limit': control_limit,
                'control_displacement': None,
                'message': None,
            }

            # Apply the pushover load in steps, summing deformations as we go, until the full pushover load has been analyzed
            while round(load_factor, 8) <= 1.0:

                # Inform the user which pushover load step we're on
                if log:
                    print('- Beginning pushover load step #' + str(step_num))
                    print(f'- Load_factor = {load_factor}')

                # Run the next pushover load step
                # Note: The validity of the pushover step is checked and handled within the _pushover_step method
                Analysis._pushover_step(self, combo.name, push_combo, step_num, P1_push, FER1_push, FER2_push, D1_indices, D2_indices, D2, log, sparse, check_stability, tol, P_Delta, max_iter)

                control_displacement = None
                if control_node is not None:
                    node = self.nodes[control_node]
                    control_displacement = float(getattr(node, control_direction.upper())[combo.name])

                if traces is not None:
                    for trace_name, trace in traces.items():
                        try:
                            self._pushover_traces[combo.name][trace_name].append(trace(combo.name))
                        except Exception as exc:
                            raise RuntimeError(
                                f"Error evaluating pushover trace '{trace_name}' for load combination '{combo.name}'."
                            ) from exc

                self._pushover_state[combo.name].update({
                    'step_num': step_num,
                    'load_factor': load_factor,
                    'control_displacement': control_displacement,
                })

                if control_limit is not None and control_displacement is not None and abs(control_displacement) >= abs(control_limit):
                    self._pushover_state[combo.name].update({
                        'status': 'target_displacement_reached',
                        'message': (
                            f"Stopped pushover at step {step_num} for load combination '{combo.name}' "
                            f"because {control_direction.upper()} at node '{control_node}' reached "
                            f"{control_displacement:.6g}, exceeding the specified limit of {control_limit:.6g}."
                        ),
                    })

                    if log:
                        print(f"- {self._pushover_state[combo.name]['message']}")

                    break

                # Move on to the next load step
                step_num += 1
                load_factor += load_step

            if self._pushover_state[combo.name]['status'] == 'running':
                self._pushover_state[combo.name].update({
                    'status': 'completed',
                    'message': 'Full pushover load applied.',
                })

        # Calculate reactions for every primary load combination
        Analysis._calc_reactions(self, log, combo_tags=['primary'])

        if log:
            print('')
            print('- Analysis complete')
            print('')

# %%
    def unique_name(self, dictionary, prefix):
        """Returns the next available unique name for a dictionary of objects.

        :param dictionary: The dictionary to get a unique name for.
        :type dictionary: dict
        :param prefix: The prefix to use for the unique name.
        :type prefix: str
        :return: A unique name for the dictionary.
        :rtype: str
        """

        # Select a trial value for the next available name
        name = prefix + str(len(dictionary) + 1)
        i = 2
        while name in dictionary.keys():
            name = prefix + str(len(dictionary) + i)
            i += 1

        # Return the next available name
        return name


    def rename(self):
        """
        Renames all the nodes and elements in the model.
        """

        # Rename each node in the model
        temp = self.nodes.copy()
        id = 1
        for old_key in temp.keys():
            new_key = 'N' + str(id)
            self.nodes[new_key] = self.nodes.pop(old_key)
            self.nodes[new_key].name = new_key
            id += 1

        # Rename each spring in the model
        temp = self.springs.copy()
        id = 1
        for old_key in temp.keys():
            new_key = 'S' + str(id)
            self.springs[new_key] = self.springs.pop(old_key)
            self.springs[new_key].name = new_key
            id += 1

        # Rename each member in the model
        temp = self.members.copy()
        id = 1
        for old_key in temp.keys():
            new_key = 'M' + str(id)
            self.members[new_key] = self.members.pop(old_key)
            self.members[new_key].name = new_key
            id += 1

        # Rename each plate in the model
        temp = self.plates.copy()
        id = 1
        for old_key in temp.keys():
            new_key = 'P' + str(id)
            self.plates[new_key] = self.plates.pop(old_key)
            self.plates[new_key].name = new_key
            id += 1

        # Rename each quad in the model
        temp = self.quads.copy()
        id = 1
        for old_key in temp.keys():
            new_key = 'Q' + str(id)
            self.quads[new_key] = self.quads.pop(old_key)
            self.quads[new_key].name = new_key
            id += 1

    def orphaned_nodes(self):
        """
        Returns a list of the names of nodes that are not attached to any elements.
        """

        # Initialize a list of orphaned nodes
        orphans = []

        # Step through each node in the model
        for node in self.nodes.values():

            orphaned = False

            # Check to see if the node is attached to any elements
            quads = [quad.name for quad in self.quads.values() if quad.i_node == node or quad.j_node == node or quad.m_node == node or quad.n_node == node]
            plates = [plate.name for plate in self.plates.values() if plate.i_node == node or plate.j_node == node or plate.m_node == node or plate.n_node == node]
            members = [member.name for member in self.members.values() if member.i_node == node or member.j_node == node]
            springs = [spring.name for spring in self.springs.values() if spring.i_node == node or spring.j_node == node]

            # Determine if the node is orphaned
            if quads == [] and plates == [] and members == [] and springs == []:
                orphaned = True

            # Add the orphaned nodes to the list of orphaned nodes
            if orphaned == True:
                orphans.append(node.name)

        return orphans

# %%
